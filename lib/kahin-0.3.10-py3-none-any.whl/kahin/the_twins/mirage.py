"""the_twins/mirage.py — Mirage: real Camoufox via the Zig IPC sidecar.

The sidecar (camoufox-harness/core/ipc_main.zig) owns the Juggler pipe and
exposes a Juggler-native JSON-over-stdio contract: requests
{"id","method","params","sessionId"?} -> {"id","result"|"error"}; events flow
out as {"method","params","sessionId"} lines, verbatim.

Faz 9 Task 3 (phantom liveness):
- ``start()`` validates boot with ``Browser.health`` (dead sidecar -> raise)
- ``call(method, params, session_id)`` is THE wire entry point (no send_cdp)
- session map is fed by ``Browser.attachedToTarget`` / ``detachedFromTarget``
  events the sidecar forwards; ``create_page/close_page/switch_page/list_pages``
  manage which target page-scoped calls run on
- reader EOF (pipe closed / child died) marks the engine dead and fires
  ``on_death`` callbacks; dead engines reject calls instead of hanging
"""

from __future__ import annotations

import asyncio
import base64
import hashlib
import json
import logging
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time
from collections import deque
from pathlib import Path
from typing import Any, Callable

import orjson

from kahin.dom_stream import DOM_STREAM_BINDING_NAME
from kahin.the_twins.chassis import BrowserEngine, EngineContext, EventData

try:
    from camoufox.utils import launch_options
except ImportError:  # pragma: no cover - harness without the camoflox package
    launch_options = None  # type: ignore[assignment]

logger = logging.getLogger(__name__)

_REQUEST_TIMEOUT = 30.0
_PAGE_NAVIGATE_RESPONSE_TIMEOUT = 5.0
# A tab-modal JS dialog (alert/confirm/prompt/beforeunload) parks the page's
# content process in a nested event loop: Juggler stops answering content
# commands on that session (Runtime.evaluate measured: no reply until the
# dialog closes) while Browser.*, Page.screenshot and Page.handleDialog keep
# answering. A command on a dialog-blocked session gets this short grace to
# answer on its own, then fails fast as ``pending_js_dialog`` instead of
# holding the agent for the full request timeout.
_DIALOG_BLOCK_GRACE = 1.5
# Bounded probes used only to classify a stalled command (never to retry it).
_STALL_PROBE_TIMEOUT = 2.0
_STALL_CAUSES = ("pending_js_dialog", "webauthn_pending", "page_busy", "dead_pipe")
_DIALOG_OPEN_EVENTS = frozenset({"Page.dialogOpened", "Page.javascriptDialogOpening"})
_DIALOG_CLOSE_EVENTS = frozenset({"Page.dialogClosed", "Page.javascriptDialogClosed"})
_IPC_WRITE_TIMEOUT = 5.0
_RESPONSE_BODY_RETRY_TIMEOUT = 5.0
_RESPONSE_BODY_RETRY_INTERVAL = 0.1
# asyncio.StreamReader defaults to 64 KiB. The sidecar deliberately returns
# bounded semantic trees/events up to 512 KiB, so the default turns a valid
# response into LimitOverrunError and kills the transport reader.
_IPC_STREAM_LIMIT = 64 * 1024 * 1024
_READER_SHUTDOWN_TIMEOUT = 1.0
# Bounded wait for the sidecar to exit after stdin EOF. The sidecar reaps
# the browser with a 10s grace (driver.zig: `inst.stop(10_000)`) before it
# SIGKILLs a wedged child. An early kill here can no longer orphan Camoufox:
# the browser child is spawned with PR_SET_PDEATHSIG=SIGKILL (pipe.zig), so
# it dies with the sidecar and cannot wedge the next browser_start on the
# profile lock. This value is therefore a latency bound, not a correctness
# one: it + the 1s reader drain + the 2s reap must stay under the 15s outer
# budget (`_ENGINE_STOP_TIMEOUT` in tools/pilot.py, `_MIRAGE_STOP_TIMEOUT`
# in tools/_common.py).
_SIDECAR_SHUTDOWN_TIMEOUT = 6.0
_SIDECAR_KILL_TIMEOUT = 2.0
# One fixed, centered window for every headed launch. Without an explicit size
# Camoufox's fingerprint generator draws a new window.outerWidth/outerHeight on
# every start and Firefox cascades each new page-window 40px down-right, so the
# same script looked different on every run. Override with
# KAHIN_WINDOW=1280x800; never fullscreen.
_DEFAULT_WINDOW_SIZE = (1280, 800)


def _window_size() -> tuple[int, int]:
    raw = os.environ.get("KAHIN_WINDOW", "").strip().lower().replace(",", "x")
    if raw:
        try:
            w, h = raw.split("x", 1)
            width, height = int(w), int(h)
            if width > 0 and height > 0:
                return (width, height)
        except (ValueError, TypeError):
            logger.warning("ignoring malformed KAHIN_WINDOW=%r; using default", raw)
    return _DEFAULT_WINDOW_SIZE


def _browser_descendant_pids(root_pid: int) -> list[int]:
    """Every descendant of ``root_pid`` (the sidecar).

    The X11 window belongs to the Camoufox child process, not to the sidecar
    that spawned it, so pinning has to look at the whole subtree.
    """
    pids: list[int] = []
    try:
        children = Path(f"/proc/{root_pid}/task/{root_pid}/children")
        stack = [int(p) for p in children.read_text().split()]
    except (OSError, ValueError):
        return pids
    while stack:
        pid = stack.pop()
        pids.append(pid)
        try:
            kids = Path(f"/proc/{pid}/task/{pid}/children").read_text().split()
            stack.extend(int(k) for k in kids)
        except (OSError, ValueError):
            continue
    return pids


def _x11_windows_for_pid(pid: int) -> list[str]:
    """Ids of the mapped top-level X11 windows owned by ``pid``.

    Firefox's own chrome window is the only NORMAL window the browser process
    owns; helper windows (the 10x10 offscreen ones) carry no window type and are
    filtered out. Returns [] when there is no display or no xdotool.
    """
    if not os.environ.get("DISPLAY"):
        return []
    try:
        out = subprocess.run(
            ["xdotool", "search", "--onlyvisible", "--pid", str(pid)],
            capture_output=True, text=True, timeout=5,
        ).stdout.split()
    except (OSError, subprocess.SubprocessError):
        return []
    windows = []
    for win in out:
        try:
            props = subprocess.run(
                ["xprop", "-id", win, "_NET_WM_WINDOW_TYPE"],
                capture_output=True, text=True, timeout=5,
            ).stdout
        except (OSError, subprocess.SubprocessError):
            continue
        if "_NET_WM_WINDOW_TYPE_NORMAL" in props:
            windows.append(win)
    return windows


def _pin_window_geometry(root_pid: int, width: int, height: int) -> None:
    """Force every normal window of the browser subtree to ``width``x``height``.

    The browser cannot do this itself: resizeTo() sets the content area, the
    window manager adds its decoration on top, and Firefox's own chrome (tab
    strip, toolbar, a sidebar that opens on some launches) varies -- so the same
    requested size produced a different outer window every time (measured
    1370x890 against 1306x757 across runs). Setting the size on the X11 window
    is authoritative and holds.
    """
    try:
        screen = subprocess.run(
            ["xdpyinfo"], capture_output=True, text=True, timeout=5,
        ).stdout
        dims = [line for line in screen.splitlines() if "dimensions:" in line]
        if not dims:
            return
        sw, sh = (int(v) for v in dims[0].split()[1].split("x")[:2])
    except (OSError, subprocess.SubprocessError, ValueError, IndexError):
        return
    left = max(0, (sw - width) // 2)
    top = max(0, (sh - height) // 2)
    windows: list[str] = []
    for pid in [root_pid, *_browser_descendant_pids(root_pid)]:
        windows.extend(_x11_windows_for_pid(pid))
    for win in dict.fromkeys(windows):
        _drive_window(win, left, top, width, height)


def _xdo(*args: str) -> str:
    try:
        return subprocess.run(
            ["xdotool", *args], capture_output=True, text=True, timeout=5,
        ).stdout
    except (OSError, subprocess.SubprocessError):
        return ""


def _frame_extents(win: str) -> tuple[int, int, int, int]:
    """(left, right, top, bottom) the window manager wraps around ``win``.

    A reparenting WM puts the client inside a frame, so xdotool windowsize --
    which sizes the client -- yields an OUTER window of client+extents. On a
    bare Xvfb there is no WM and these are all zero; under KWin the same
    request grew the outer window to the measured 1370x890.
    """
    try:
        props = subprocess.run(
            ["xprop", "-id", win, "_NET_FRAME_EXTENTS"],
            capture_output=True, text=True, timeout=5,
        ).stdout
    except (OSError, subprocess.SubprocessError):
        return (0, 0, 0, 0)
    if "=" not in props:
        return (0, 0, 0, 0)
    try:
        values = [int(v.strip()) for v in props.split("=", 1)[1].split(",")]
    except ValueError:
        return (0, 0, 0, 0)
    return tuple(values[:4]) if len(values) >= 4 else (0, 0, 0, 0)  # type: ignore[return-value]


def _client_geometry(win: str) -> tuple[int, int, int, int] | None:
    """(x, y, width, height) of the client area, as the server reports it."""
    geom = dict(
        kv.split("=", 1) for kv in _xdo("getwindowgeometry", "--shell", win).split()
        if "=" in kv
    )
    try:
        return (int(geom["X"]), int(geom["Y"]), int(geom["WIDTH"]), int(geom["HEIGHT"]))
    except (KeyError, ValueError):
        return None


def _outer_of(win: str) -> tuple[int, int, int, int] | None:
    """(x, y, width, height) of the window including its WM frame."""
    client = _client_geometry(win)
    if client is None:
        return None
    x, y, w, h = client
    fl, fr, ft, fb = _frame_extents(win)
    return (x - fl, y - ft, w + fl + fr, h + ft + fb)


def _drive_window(win: str, left: int, top: int, width: int, height: int) -> None:
    """Closed loop: measure the real outer box and correct until it lands.

    Blindly issuing windowsize is not enough -- xdotool sizes the CLIENT, the
    WM decides the frame, and the resulting outer size differs per display
    (0px on bare Xvfb, +90px under KWin measured on :0). Reading back what the
    server actually granted and steering on the error converges on both.
    """
    for _ in range(6):
        outer = _outer_of(win)
        client = _client_geometry(win)
        if outer is None or client is None:
            return
        ox, oy, ow, oh = outer
        cx, cy, cw, ch = client
        dw, dh = width - ow, height - oh
        dx, dy = left - ox, top - oy
        if not (dx or dy or dw or dh):
            return
        if dw or dh:
            _xdo("windowsize", win, str(max(1, cw + dw)), str(max(1, ch + dh)))
        if dx or dy:
            _xdo("windowmove", win, str(cx + dx), str(cy + dy))


async def _pin_window_geometry_until_settled(pid: int) -> None:
    """Pin right after the window appears, and again whenever it drifts.

    Firefox maps its chrome window a moment after boot and the window manager
    may place it afterwards, so the first attempt can land before the window
    exists. Poll briefly, then keep a slow watch for the life of the engine so a
    late resize cannot move it.
    """
    width, height = _window_size()
    for _ in range(80):  # ~20s to first map
        if any(_x11_windows_for_pid(p) for p in [pid, *_browser_descendant_pids(pid)]):
            _pin_window_geometry(pid, width, height)
            break
        await asyncio.sleep(0.25)
    while True:
        await asyncio.sleep(1.0)
        _pin_window_geometry(pid, width, height)
_MIRAGE_PAGE_DOMAINS = frozenset({"Page", "Runtime", "Network", "Input", "Accessibility", "Heap"})

# Faz 4 Task 3 — per-identity profile pre-warm. Camoufox's launch_options()
# deliberately injects per-launch randomness (font/voice subsets, spacing/
# audio/canvas seeds, webgl sampling, window.history.length), so neither the
# full options dict nor the runtime profile directory can be cached or
# reused safely: a reused profile would restore cookies/session data, and a
# pinned options snapshot would freeze the per-launch fingerprint rotation
# that Faz 3's identity tests rely on. The safe seam is therefore bounded
# preparation metadata only — a stable identity hash plus measured prep
# timings — kept in-process and mirrored to a small per-identity file under
# the cache dir. It never skips real launch work and never contains identity
# payloads.
_PREWARM_CACHE_MAX = 8
_PREWARM_METADATA_MAX = 4096  # bytes written per identity
_PREWARM_READ_MAX = 8192  # refuse metadata files larger than this
_PREWARM_CACHE: dict[str, dict[str, Any]] = {}

_PROFILE_DIR_ENV = "KAHIN_PROFILE_DIR"
_PROFILE_DIR_MAX_LENGTH = 4096
_KES_TEMP_PREFIX = "kahin-kes-"
_LEGACY_TEMP_PREFIX = "kahin-fp-"
_KES_SWEEP_MAX_ENTRIES = 512

# Directories created for this process's kes launches. The stale-dir sweep
# must never delete a directory a live engine still owns.
_LIVE_KES_DIRS: set[str] = set()

# Durum modları (spec §2). Kanonik adlar sahibinin verdiği Türkçe adlardır;
# İngilizce karşılık uydurulmaz ("kahin" -> "oracle" gibi). Dizin adları ise
# dosya yolu güvenliği için ASCII kalır (agirbas/, kes/).
STATE_MODE_AGIRBAS = "ağırbaş"
STATE_MODE_KES = "keş"

_STATE_MODE_ALIASES = {
    STATE_MODE_AGIRBAS: STATE_MODE_AGIRBAS,
    "ağirbaş": STATE_MODE_AGIRBAS,  # "AĞIRBAŞ".lower() in Python produces dotted-i after ğ
    "agirbas": STATE_MODE_AGIRBAS,
    STATE_MODE_KES: STATE_MODE_KES,
    "kes": STATE_MODE_KES,
}

_MAX_ACTIVE_SUBAGENTS = 0  # 0 = unconstrained N-parallelism
_DEFAULT_SUBAGENT_IDLE_TTL = 1800.0  # 30 minutes safety idle timeout for abandoned tabs


def _canonical_state_mode(mode: str) -> str:
    """Verilen mod adını kanonik Türkçe ada çevir (``ağırbaş``/``keş``)."""
    if not isinstance(mode, str) or not mode.strip():
        raise ValueError("mode 'ağırbaş' ya da 'keş' olmalı")
    canonical = _STATE_MODE_ALIASES.get(mode.strip().lower())
    if canonical is None:
        raise ValueError("mode 'ağırbaş' ya da 'keş' olmalı")
    return canonical


def _kahin_home() -> Path:
    """Resolve the Kahin data home (spec §6).

    ``$KAHIN_HOME`` when set, else ``$XDG_DATA_HOME/kahin``, else
    ``~/.local/share/kahin``.
    """
    configured = os.environ.get("KAHIN_HOME", "").strip()
    if configured:
        return Path(configured).expanduser()
    data_home = os.environ.get("XDG_DATA_HOME", "").strip()
    root = Path(data_home).expanduser() if data_home else Path.home() / ".local" / "share"
    return root / "kahin"


def _absolute_profile_path(configured: str) -> Path:
    """Validate an explicit profile directory (non-empty, bounded, absolute)."""
    if not isinstance(configured, str) or not configured.strip():
        raise ValueError("profile directory must be a non-empty absolute path")
    path = Path(configured.strip()).expanduser()
    if len(str(path)) > _PROFILE_DIR_MAX_LENGTH:
        raise ValueError(f"profile directory exceeds {_PROFILE_DIR_MAX_LENGTH} characters")
    if not path.is_absolute():
        raise ValueError("profile directory must be an absolute path")
    return path


def _agirbas_profile_dir(configured: str | None = None) -> Path:
    """Stable, permanent profile directory for the ``agirbas`` mode.

    Performs the one-time legacy migration from spec §6: an existing
    ``$KAHIN_HOME/profile`` is renamed to ``$KAHIN_HOME/agirbas/profile`` so
    the user's existing uBlock/Bitwarden data is preserved. If the rename
    fails the legacy path is used in place — data is never destroyed.
    """
    if configured is not None and str(configured).strip():
        return _absolute_profile_path(configured)
    env_override = os.environ.get(_PROFILE_DIR_ENV, "").strip()
    if env_override:
        return _absolute_profile_path(env_override)
    home = _kahin_home()
    legacy = home / "profile"
    target = home / "agirbas" / "profile"
    if not target.exists() and legacy.exists():
        try:
            target.parent.mkdir(parents=True, exist_ok=True)
            os.rename(legacy, target)
        except OSError:
            logger.warning(
                "legacy profile migration failed; continuing with the legacy path",
                exc_info=True,
            )
    if target.exists():
        return target
    if legacy.exists():
        return legacy
    return target


def _new_kes_profile() -> Path:
    """Create a fresh, unique ephemeral profile for one ``kes`` launch.

    The directory lives under ``$KAHIN_HOME/kes`` when that root is
    creatable, otherwise in the system temp dir.
    """
    root = _kahin_home() / "kes"
    dir_arg: str | None = None
    try:
        root.mkdir(parents=True, exist_ok=True)
        dir_arg = str(root)
    except OSError:
        dir_arg = None
    return Path(tempfile.mkdtemp(prefix=_KES_TEMP_PREFIX, dir=dir_arg))


def _is_kes_owned_path(path: Path) -> bool:
    """True only for a ``kahin-kes-*`` dir under the kes root or the temp dir."""
    if not path.name.startswith(_KES_TEMP_PREFIX):
        return False
    parent = path.parent
    if parent == _kahin_home() / "kes":
        return True
    return parent == Path(tempfile.gettempdir())


def _is_sweepable_kes_path(path: Path) -> bool:
    """True for stale ephemeral dirs the sweep is allowed to remove."""
    if path.name.startswith(_KES_TEMP_PREFIX) or path.name.startswith(_LEGACY_TEMP_PREFIX):
        return True
    return path.parent == _kahin_home() / "kes"


def _sweep_stale_kes_dirs() -> int:
    """Remove leftover ephemeral profile dirs no live engine owns (spec §2.2).

    Bounded to the kes root and the known temp prefixes; symlinks and dirs
    registered as live are never removed. Returns the number of directories
    deleted.
    """
    candidates: list[Path] = []
    kes_root = _kahin_home() / "kes"
    try:
        if kes_root.is_dir():
            candidates.extend(list(kes_root.iterdir())[:_KES_SWEEP_MAX_ENTRIES])
    except OSError:
        pass
    tmp_root = Path(tempfile.gettempdir())
    for prefix in (_KES_TEMP_PREFIX, _LEGACY_TEMP_PREFIX):
        try:
            candidates.extend(list(tmp_root.glob(prefix + "*"))[:_KES_SWEEP_MAX_ENTRIES])
        except OSError:
            pass
    removed = 0
    seen: set[str] = set()
    for entry in candidates:
        key = str(entry)
        if key in seen or key in _LIVE_KES_DIRS:
            continue
        seen.add(key)
        if entry.is_symlink() or not entry.is_dir():
            continue
        if not _is_sweepable_kes_path(entry):
            continue
        shutil.rmtree(entry, ignore_errors=True)
        removed += 1
    return removed


def _state_mode_directory(
    mode: str,
    configured: str | None,
) -> tuple[Path | None, str]:
    """Resolve the profile directory for a state mode (spec §2/§6).

    Returns ``(profile_dir, canonical_mode)``. ``agirbas`` resolves to the one
    permanent home; ``kes`` creates a fresh, unique temp profile per call so
    ``stop()`` can delete exactly the directory this launch created.
    """
    canonical = _canonical_state_mode(mode)
    if canonical == STATE_MODE_AGIRBAS:
        return _agirbas_profile_dir(configured), canonical
    return _new_kes_profile(), canonical


def _profile_directory(
    persistent: bool,
    configured: str | None,
) -> tuple[Path | None, bool]:
    """Back-compat mapping onto the two state modes (spec §2.3).

    ``persistent=True`` -> agirbas resolution, ``persistent=False`` -> kes.
    """
    path, canonical = _state_mode_directory(STATE_MODE_AGIRBAS if persistent else STATE_MODE_KES, configured)
    return path, canonical == STATE_MODE_AGIRBAS


def _profile_cache_dir() -> Path:
    """Bounded cache root for per-identity pre-warm metadata."""
    env = os.environ.get("KAHIN_PROFILE_CACHE_DIR")
    path = Path(env).expanduser() if env else (Path.home() / ".cache" / "kahin" / "profiles")
    return path


def _identity_hash(config: dict[str, Any]) -> str:
    """Stable, safe key for an identity config: sha256 of canonical JSON."""
    raw = json.dumps(config, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()[:16]


def _effective_identity_hash(env: dict[str, Any], policy: dict[str, Any]) -> str:
    """Stable, bounded digest of the effective launch identity material.

    Default (fresh BrowserForge) launches have no pinned config to hash, so
    the effective identity material is the ``CAMOU_CONFIG_*`` fingerprint
    env generated for THIS launch plus the safe launch policy (headless/
    humanize/cache/webgl/main-world and proxy presence). The raw fingerprint
    payload exists only inside this function — callers store and expose just
    the 16-hex digest, never the config itself.
    """
    material: dict[str, Any] = {
        "policy": policy,
        "camou_config": {
            key: value
            for key, value in env.items()
            if key.startswith("CAMOU_CONFIG_") and isinstance(value, (str, int, float, bool))
        },
    }
    raw = json.dumps(material, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()[:16]


def _prewarm_load(identity_hash: str) -> dict[str, Any] | None:
    """In-process first, then bounded on-disk metadata lookup (never raises)."""
    entry = _PREWARM_CACHE.get(identity_hash)
    if entry is not None:
        return {**entry, "source": "memory"}
    path = _profile_cache_dir() / f"{identity_hash}.json"
    try:
        raw = path.read_bytes()
        if len(raw) > _PREWARM_READ_MAX:
            return None
        parsed = json.loads(raw)
    except (OSError, ValueError):
        return None
    if not isinstance(parsed, dict) or parsed.get("identity_hash") != identity_hash:
        return None
    return {**parsed, "source": "disk"}


def _prewarm_record(identity_hash: str, entry: dict[str, Any]) -> None:
    """Bound the in-process cache and mirror metadata to disk (never raises)."""
    _PREWARM_CACHE[identity_hash] = entry
    while len(_PREWARM_CACHE) > _PREWARM_CACHE_MAX:
        _PREWARM_CACHE.pop(next(iter(_PREWARM_CACHE)))
    path = _profile_cache_dir() / f"{identity_hash}.json"
    try:
        payload = json.dumps(entry, sort_keys=True).encode("utf-8")
        if len(payload) > _PREWARM_METADATA_MAX:
            return
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_name(path.name + ".tmp")
        tmp.write_bytes(payload)
        tmp.replace(path)
    except OSError:
        pass


def _needs_mirage_page_for_adapter(domain: str, command: str) -> bool:
    return domain in _MIRAGE_PAGE_DOMAINS and not (domain == "Page" and command == "close")


def _sidecar_bin() -> Path:
    env = os.environ.get("KAHIN_ZIG_CORE")
    if env:
        path = Path(env) / "zig-out" / "bin" / "kahin-sidecar"
        if path.is_file():
            return path
        raise RuntimeError(f"KAHIN_ZIG_CORE points to a missing sidecar: {path}")
    # Installed wheel ships the sidecar inside the package (kahin/_vendor/);
    # source-tree installs use the repo copy. Prefer the package copy so the
    # pip-installed runtime (pnpm launcher -> PyPI) never needs the repo.
    pkg = Path(__file__).resolve().parents[1] / "_vendor" / "kahin-sidecar"
    if pkg.is_file():
        return pkg
    path = (
        Path(__file__).resolve().parents[2] / "camoufox-harness" / "vendor" / "bin" / "kahin-sidecar"
    )
    if not path.is_file():
        raise RuntimeError(
            f"Vendored sidecar binary missing: {path}. Rebuild it with scripts/build-sidecar.sh"
        )
    return path


def _camoufox_readiness_error(reason: str, **details: Any) -> RuntimeError:
    """Build a stable, actionable error for missing Camoufox readiness."""
    payload: dict[str, Any] = {
        "error": "camoufox_not_ready",
        "reason": reason,
        "actions": {
            "install_package": f"{sys.executable} -m pip install camoufox",
            "fetch_browser": f"{sys.executable} -m camoufox fetch",
            "explicit_binary": "KAHIN_CAMOUFOX_BIN=/absolute/path/to/camoufox-bin",
        },
    }
    payload.update(details)
    return RuntimeError(f"Camoufox readiness failed: {json.dumps(payload, sort_keys=True)}")


def _usable_camoufox_bin(path: Path) -> bool:
    """Require a real executable, not merely a stale cache entry."""
    return path.is_file() and (os.name == "nt" or os.access(path, os.X_OK))


def _installed_engine_candidates() -> list[Path]:
    """Kahin-managed Camoufox engines under ``$KAHIN_HOME/engines``.

    These are source-built (patched) distributions, not the volatile
    Camoufox cache. ``current`` is the operator-selected engine; every
    other version directory is a fallback so an upgrade cannot hide the
    last known-good build behind a missing symlink.
    """
    root = _kahin_home() / "engines"
    candidates: list[Path] = []
    current = root / "current" / "camoufox-bin"
    if _usable_camoufox_bin(current):
        candidates.append(current)
    try:
        for path in sorted(root.glob("*/camoufox-bin")):
            if path not in candidates and _usable_camoufox_bin(path):
                candidates.append(path)
    except OSError:
        pass
    return candidates


def _camoufox_ff_version(binary: Path) -> str | None:
    """Firefox version of a resolved engine from its sibling version.json.

    ``launch_options`` otherwise reads the version from Camoufox's cache
    (``installed_verstr``), which makes a cache-free install impossible.
    Returning the version here keeps the fingerprint presets and font
    selection correct without any cache-resident browser.
    """
    for candidate in (binary.parent / "version.json", binary.parent.parent / "version.json"):
        try:
            data = json.loads(candidate.read_text())
        except (OSError, ValueError):
            continue
        version = data.get("version") if isinstance(data, dict) else None
        if isinstance(version, str) and version.strip():
            return version.strip()
    return None


def _camoufox_bin() -> Path:
    """Resolve the Camoufox binary to launch.

    Only a Kahin-managed engine (``$KAHIN_HOME/engines``) or an explicit
    ``KAHIN_CAMOUFOX_BIN`` is accepted. The Camoufox package cache holds a
    different, unpatched build whose fingerprint and stealth behaviour differ;
    falling back to it silently hid which binary actually ran, so that path is
    gone and the operator must name a non-managed build explicitly.
    """
    env = os.environ.get("KAHIN_CAMOUFOX_BIN")
    if env:
        path = Path(env).expanduser()
        if _usable_camoufox_bin(path):
            return path
        raise _camoufox_readiness_error(
            "invalid_explicit_binary",
            path=str(path),
            detail="KAHIN_CAMOUFOX_BIN must point to an executable Camoufox binary.",
        )

    installed = _installed_engine_candidates()
    if installed:
        return installed[0]

    raise _camoufox_readiness_error(
        "managed_engine_missing",
        detail=(
            "No Kahin-managed Camoufox engine under $KAHIN_HOME/engines. Refusing "
            "to silently run an unpatched build from Camoufox's cache; install the "
            "fork engine or set KAHIN_CAMOUFOX_BIN explicitly."
        ),
        enginesRoot=str(_kahin_home() / "engines"),
        actions={
            "install_engine": "point $KAHIN_HOME/engines/current at the patched build",
            "explicit_binary": "KAHIN_CAMOUFOX_BIN=/absolute/path/to/camoufox-bin",
        },
    )


class MirageCommandTimeout(RuntimeError):
    """A Juggler command got no reply; ``diagnosis`` says why.

    ``diagnosis["cause"]`` is one of ``pending_js_dialog``,
    ``webauthn_pending``, ``page_busy`` or ``dead_pipe``. Only ``dead_pipe``
    means the transport is gone; the other three are page-side locks that a
    longer timeout or an engine restart cannot clear.
    """

    def __init__(self, message: str, diagnosis: dict[str, Any]) -> None:
        super().__init__(message)
        self.diagnosis = diagnosis

    @property
    def cause(self) -> str:
        return str(self.diagnosis.get("cause") or "page_busy")


class _DialogBlocked(Exception):
    """Internal: a reply is held behind an open JS dialog on its session."""


class Mirage(BrowserEngine):
    """Stealth Camoufox engine speaking Juggler methods over the Zig sidecar."""

    def __init__(self, engine_name: str = "mirage") -> None:
        super().__init__()
        self._engine_name = engine_name
        self._stderr_file = None
        self._stderr_path: Path | None = None
        self._profile_dir: Path | None = None
        self._persistent_profile = False
        self._state_mode: str | None = None
        self._kes_profile_dir: Path | None = None
        self._headless = True
        self._marionette_port: int | None = None
        self._passkey_mode = False
        self._addons: list[str] = []
        # Active identity applied at launch (Faz 2 Task 5): the resolved
        # fingerprint config plus the saved identity name it came from.
        # Retained only while this engine is running, for
        # ``kahin_identity_report``.
        self._identity_config: dict[str, Any] | None = None
        self._identity_name: str | None = None
        self._proxy_url: str | None = None
        # Faz 4 Task 3: pre-warm metadata + monotonic uptime anchor. Kept
        # only while this engine is running; cleared in stop().
        self._identity_hash: str | None = None
        self._prewarm_info: dict[str, Any] | None = None
        # Crawler/rotation Task 1: the launch policy actually bound on this
        # start (headless/humanize/cache/webgl/main-world + proxy presence),
        # exposed by identity/status surfaces without any fingerprint data.
        self._launch_policy: dict[str, Any] | None = None
        self._started_monotonic: float | None = None
        self._geometry_task: asyncio.Task[None] | None = None
        self._write_lock = asyncio.Lock()
        self._page_lock = asyncio.Lock()
        # Switching the current tab is a routing operation, not browser
        # state that can be changed halfway through resolving a call. The
        # lock only protects target/session selection; wire calls themselves
        # remain concurrent behind ``_write_lock`` and the pending map.
        self._target_lock = asyncio.Lock()
        # targetId -> Juggler sessionId, learned from attachedToTarget events.
        self._sessions: dict[str, str] = {}
        self._target_infos: dict[str, dict[str, Any]] = {}
        self._current_target: str | None = None
        self._agent_targets: dict[str, str] = {}
        self._agent_contexts: dict[str, str] = {}
        self._agent_last_seen: dict[str, float] = {}
        self._agent_in_flight: dict[str, int] = {}
        self._user_agent_overrides: dict[str, str] = {}
        # sessionId -> {frameId -> executionContextId} (main world only),
        # fed by Runtime.executionContextCreated/Destroyed/ContextsCleared
        # events the sidecar forwards verbatim. DOM tools resolve a frame_id
        # to the main-world context of that frame.
        self._frame_contexts: dict[str, dict[str, str]] = {}
        # Page.fileChooserOpened (file-input click while interception is on):
        # bounded per-session queue, consumed by wait_for_chooser (Gap C
        # upload). A single global slot lets a second tab steal the first
        # tab's chooser during concurrent uploads.
        self._pending_choosers: deque[tuple[str | None, dict[str, Any]]] = deque(maxlen=32)
        self._chooser_event = asyncio.Event()
        # Page.screencastFrame (live screencast, Gap D): params of every
        # unconsumed frame (data is base64-JPEG, ack'd on consume — see
        # wait_for_screencast_frame). The event carries NO screencastId, so
        # the stream id returned by Page.startScreencast is tracked here and
        # echoed back on every screencastFrameAck.
        self._screencast_frames: deque[dict[str, Any]] = deque(maxlen=64)
        self._screencast_event = asyncio.Event()
        self._screencast_id: str | None = None
        self._screencast_session_id: str | None = None
        self._screencast_starting = False
        self._screencast_starting_session_id: str | None = None
        self._screencast_generation = 0
        self._screencast_lock = asyncio.Lock()
        # Real-time DOM observation uses the browser's native binding/event
        # bridge. The page owns the bounded mutation ring; this signal only
        # wakes a waiting tool so the reader never carries DOM payloads.
        self._dom_binding_installed = False
        self._dom_init_script_installed = False
        self._dom_signal = asyncio.Event()
        # Network interception is surfaced by Network.requestWillBeSent with
        # params.isIntercepted=true in this Juggler build. Keep a bounded,
        # engine-local queue so a route decision cannot consume another tab's
        # request from the global diagnostic buffer.
        self._network_events: deque[dict[str, Any]] = deque(maxlen=2_000)
        self._network_signal = asyncio.Event()
        self._network_routed_ids: set[str] = set()
        # sessionId -> {dialogId -> dialog info}: tab-modal JS dialogs that
        # are open right now, fed by Page.dialogOpened/dialogClosed in the
        # reader. ``call`` races every reply against ``_dialog_changed`` so a
        # dialog opening mid-flight releases the waiter immediately.
        self._open_dialogs: dict[str, dict[str, dict[str, Any]]] = {}
        self._dialog_changed = asyncio.Event()
        # (monotonic time, diagnosis) of the latest classified stall; the MCP
        # harness re-attaches it to tool answers that flattened the error.
        self._last_stall: tuple[float, dict[str, Any]] | None = None

    def _reset_capture_state(self, *, wake_waiters: bool) -> None:
        """Drop capture/chooser state that belongs to the old browser.

        Capture events are not durable browser state. Keeping them across a
        stop/start cycle can make a later upload consume an old chooser or a
        later screencast return a frame from a previous stream. On shutdown,
        wake waiters so they can observe liveness immediately; start() clears
        the wake-up events before the new browser is exposed.
        """
        self._pending_choosers.clear()
        self._screencast_frames.clear()
        self._screencast_id = None
        self._screencast_session_id = None
        self._screencast_starting = False
        self._screencast_starting_session_id = None
        self._network_events.clear()
        self._network_routed_ids.clear()
        self._open_dialogs.clear()
        self._notify_dialog_change()
        self._last_stall = None
        if wake_waiters:
            self._chooser_event.set()
            self._screencast_event.set()
            self._network_signal.set()
        else:
            self._chooser_event.clear()
            self._screencast_event.clear()
            self._network_signal.clear()

    async def start(
        self,
        headless: bool = True,
        port: int = 0,
        *,
        passkey_mode: bool = False,
        **kwargs: Any,
    ) -> EngineContext:
        del port  # Juggler pipe: no port.
        self._headless = bool(headless)
        # A Mirage object is normally single-use, but resetting these fields
        # makes a stop/start cycle deterministic and prevents stale tab or
        # liveness state from leaking into a replacement browser.
        self._dead = False
        self._stopping = False
        self._msg_id = 0
        self._sessions.clear()
        self._target_infos.clear()
        self._frame_contexts.clear()
        self._current_target = None
        self._agent_targets.clear()
        self._agent_contexts.clear()
        self._agent_last_seen.clear()
        self._agent_in_flight.clear()
        self._user_agent_overrides.clear()
        self._dom_binding_installed = False
        self._dom_init_script_installed = False
        self._dom_signal.clear()
        self._network_events.clear()
        self._network_routed_ids.clear()
        self._network_signal.clear()
        self._reset_capture_state(wake_waiters=False)
        self._identity_config = None
        self._identity_name = None
        self._proxy_url = None
        self._identity_hash = None
        self._prewarm_info = None
        self._launch_policy = None
        self._started_monotonic = None
        self._geometry_task = None
        self._persistent_profile = False
        self._state_mode = None
        self._kes_profile_dir = None
        self._marionette_port = None
        self._passkey_mode = False
        configured_profile = kwargs.get("profile_dir")
        requested_mode = kwargs.get("mode")
        persistent_profile = kwargs.get("persistent_profile", True)
        if not isinstance(persistent_profile, bool):
            raise ValueError("persistent_profile must be a boolean")
        if not isinstance(passkey_mode, bool):
            raise ValueError("passkey_mode must be a boolean")
        if requested_mode is None:
            # Back-compat (spec §2.3): persistent_profile maps onto the modes.
            mode = STATE_MODE_AGIRBAS if persistent_profile else STATE_MODE_KES
        else:
            mode = _canonical_state_mode(requested_mode)
        if passkey_mode and mode != STATE_MODE_AGIRBAS:
            raise ValueError("passkey_mode requires persistent_profile=True")
        self._passkey_mode = passkey_mode
        _sweep_stale_kes_dirs()
        profile_dir, canonical_mode = _state_mode_directory(mode, configured_profile)
        self._state_mode = canonical_mode
        self._persistent_profile = canonical_mode == STATE_MODE_AGIRBAS
        self._kes_profile_dir = profile_dir if canonical_mode == STATE_MODE_KES else None
        if self._kes_profile_dir is not None:
            _LIVE_KES_DIRS.add(str(self._kes_profile_dir))
        if passkey_mode:
            # Firefox Marionette shares the existing Camoufox process. Bind
            # to loopback only and release immediately so Firefox can claim
            # this ephemeral port during startup.
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
                sock.bind(("127.0.0.1", 0))
                self._marionette_port = int(sock.getsockname()[1])
        addons_input = kwargs.get("addons")
        validated_addons: list[str] = []
        if addons_input is not None:
            if not isinstance(addons_input, (list, tuple)):
                raise ValueError("addons must be a list of staged addon directory paths")
            if len(addons_input) > 16:
                raise ValueError("addons exceeds maximum 16 extensions")
            from kahin.extensions import inspect_extension
            for item in addons_input:
                if not isinstance(item, str) or not item.strip():
                    raise ValueError("addon item must be a non-empty string")
                report = inspect_extension(item)
                if not report.get("compatible"):
                    unsupported_str = ", ".join(report.get("unsupported", []))
                    raise ValueError(f"Addon '{item}' is not compatible: {unsupported_str}")
                validated_addons.append(report["path"])
        self._addons = validated_addons
        identity_config = kwargs.get("identity")
        identity_name = kwargs.get("identity_name")
        self._identity_config = (
            identity_config if isinstance(identity_config, dict) and identity_config else None
        )
        self._identity_name = identity_name if isinstance(identity_name, str) and identity_name else None
        # Per-identity profile pre-warm (Faz 4 Task 3): resolve the stable
        # identity hash and check the bounded preparation-metadata cache.
        # A cache hit only records that this identity was prepared before;
        # launch_options is still called because its output is randomized
        # per launch by design (see the module docstring on _PREWARM_CACHE).
        prewarm: dict[str, Any] | None = None
        prewarm_hash: str | None = None
        if self._identity_config is not None:
            prewarm_hash = _identity_hash(self._identity_config)
            prewarm = _prewarm_load(prewarm_hash)
        # Validate the proxy before constructing launch options so the same
        # validated value can drive Camoufox's native proxy/geoip seam
        # (geoip resolves the exit IP THROUGH the proxy) and the Juggler
        # Browser.setBrowserProxy call after boot. Credentials remain internal
        # to the launch call and the params; no display/log path receives the
        # raw URL. An invalid URL fails the start (fail closed) instead of
        # silently running proxyless.
        proxy_url = kwargs.get("proxy")
        validated_proxy_url: str | None = None
        proxy_params: dict[str, Any] | None = None
        if isinstance(proxy_url, str) and proxy_url.strip():
            from kahin.stealth import proxy_juggler_params  # noqa: PLC0415 - pure helper

            candidate_proxy_url = proxy_url.strip()
            proxy_params = proxy_juggler_params(candidate_proxy_url)
            validated_proxy_url = candidate_proxy_url
        # Real launch policy (crawler/rotation Task 1): the same fixed
        # Camoufox options are bound on EVERY start — default and identity —
        # so fingerprint generation, user.js prefs and args never drift from
        # the enabled stealth policy. ``headless`` is the caller's real
        # flag; ``main_world_eval=False`` keeps the Juggler main-world
        # binding off (the DOM stream uses browser-level addBinding and
        # init scripts, never allowMainWorld).
        from kahin.stealth import launch_policy  # noqa: PLC0415 - pure helper

        policy = launch_policy(headless=headless)
        # Resolve the engine once. A Kahin-managed engine (source-built with
        # our patches) wins over Camoufox's cache, and its version metadata
        # feeds launch_options so no cache-resident active version is needed.
        camoufox_bin = await asyncio.to_thread(_camoufox_bin)
        ff_version = _camoufox_ff_version(camoufox_bin)
        # launch_options takes `config` and `firefox_user_prefs` as named
        # parameters, so they must never ride inside **launch_kwargs — the
        # identity path below passes its own `config=` and would collide.
        policy_config: dict[str, Any] = dict(policy.get("config") or {})
        policy_prefs: dict[str, Any] = dict(policy.get("firefox_user_prefs") or {})
        launch_kwargs: dict[str, Any] = {
            key: value for key, value in policy.items()
            if key not in ("config", "firefox_user_prefs")
        }
        launch_kwargs["firefox_user_prefs"] = policy_prefs
        # One window, one geometry, nothing moves. `window.open` popups and
        # target=_blank links become tabs in the same window instead of new
        # windows, and no page may resize or move the chrome window at all.
        # 3 = new tab in the same window (1 would replace the current page,
        # which destroys whatever the automation had open).
        policy_prefs.setdefault("browser.link.open_newwindow", 3)
        policy_prefs.setdefault("browser.link.open_newwindow.restriction", 0)
        # NOTE: dom.disable_window_move_resize is deliberately NOT set. It
        # applies to the chrome window too, which turns the Juggler side's
        # moveTo/resizeTo into no-ops -- disarming the geometry pin and letting
        # the window manager decide the position. Content scripts are already
        # blocked from moving chrome windows by Firefox itself.
        # Pin one geometry per launch instead of letting the fingerprint
        # generator pick a random window each start. The Juggler side reads
        # these prefs and centers the window on screen.
        window_size = _window_size()
        launch_kwargs.setdefault("window", window_size)
        policy_prefs.setdefault("kahin.window.width", window_size[0])
        policy_prefs.setdefault("kahin.window.height", window_size[1])
        launch_kwargs["executable_path"] = str(camoufox_bin)
        if ff_version:
            launch_kwargs["ff_version"] = ff_version
            launch_kwargs["i_know_what_im_doing"] = True
        if self._addons:
            launch_kwargs["addons"] = self._addons
        if validated_proxy_url is not None:
            # Camoufox uses this native proxy config for proxy-aware
            # fingerprint geo alignment. The raw URL is passed only to the
            # library; it is never logged or returned by Kahin.
            launch_kwargs.update({
                "proxy": {"server": validated_proxy_url},
                "geoip": True,
            })
        # BrowserForge fingerprint -> CAMOU_CONFIG_* env (master plan §2.1.5).
        # Every start() draws a fresh identity; the sidecar passes our
        # environment through to the Camoufox child verbatim (pipe.zig
        # buildEnvp reads /proc/self/environ).
        opts_t0 = time.monotonic()
        if launch_options is None:
            opts = {"env": {}, "firefox_user_prefs": {}}
        else:
            try:
                opts = launch_options(config=policy_config, **launch_kwargs)
            except Exception as exc:  # noqa: BLE001 - geoip is an optional proxy seam
                if validated_proxy_url is None or launch_kwargs.get("geoip") is not True:
                    raise
                # Native geo alignment performs an external IP lookup through
                # the proxy. A dead, local, or temporarily unavailable proxy
                # must not prevent the browser from starting; retain the
                # proxy and fall back to proxy-only launch semantics.
                logger.warning(
                    "Camoufox geoip lookup failed; continuing with proxy-only launch (%s)",
                    type(exc).__name__,
                )
                launch_kwargs = {**launch_kwargs, "geoip": False}
                opts = launch_options(config=policy_config, **launch_kwargs)
        # Identity config (Faz 2 Task 5): merge through the same seam that
        # applies the default fingerprint. ``launch_options(config=...)``
        # regenerates the full option set (env with CAMOU_CONFIG_*, user.js
        # prefs, args) and overlays the pinned values on top, so unrelated
        # defaults are preserved and the identity takes precedence. A failed
        # injection must never crash boot; fall back to a fresh random
        # fingerprint instead.
        if self._identity_config is not None:
            if launch_options is None:
                logger.warning("identity config ignored: camoufox launch_options unavailable")
            else:
                try:
                    opts = launch_options(
                        config={**policy_config, **self._identity_config},
                        i_know_what_im_doing=True,
                        **launch_kwargs,
                    )
                except Exception:  # noqa: BLE001 - identity must not crash boot
                    logger.warning("identity config injection failed; using defaults", exc_info=True)
        opts_ms = (time.monotonic() - opts_t0) * 1000
        env = {**os.environ, **opts["env"]}
        if self._passkey_mode:
            env["MOZ_MARIONETTE"] = "1"
        else:
            env.pop("MOZ_MARIONETTE", None)
        # Allow hardware GPU acceleration unless explicitly overridden by environment
        if os.environ.get("KAHIN_FORCE_SOFTWARE_GL") == "1":
            env["LIBGL_ALWAYS_SOFTWARE"] = "1"
        # Proxy (Faz 3 Task 5): the browser-level proxy is applied through
        # the Juggler ``Browser.setBrowserProxy`` call after boot (see below),
        # NOT through the child environment. Firefox's environment-proxy path
        # only accepts ``http://`` proxy URLs, so a socks URL exported here is
        # silently dropped and the browser leaks the real IP via a DIRECT
        # connection. Strip any ambient proxy env when a proxy is configured
        # so no second, divergent mechanism can apply. The raw URL is retained
        # as engine metadata so a later browser_start reuse can detect a
        # requested configuration mismatch instead of silently ignoring it.
        if proxy_params is not None and validated_proxy_url is not None:
            for _key in (
                "HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY", "NO_PROXY",
                "http_proxy", "https_proxy", "all_proxy", "no_proxy",
            ):
                env.pop(_key, None)
            self._proxy_url = validated_proxy_url
        else:
            self._proxy_url = None

        # Safe launch metadata for the surfaces (never the raw fingerprint
        # or proxy URL): the bound policy plus proxy presence only.
        self._launch_policy = {**policy, "proxy": self._proxy_url is not None}
        # Every launch reports the effective CAMOU_CONFIG_* material actually
        # handed to Camoufox, including launches seeded from a saved identity.
        # The saved identity remains the configuration input, but does not
        # freeze the per-launch fingerprint. A restart must either produce a
        # different real digest or be rejected by the crawler rotation gate.
        # Raw fingerprint payloads are never logged or returned.
        self._identity_hash = _effective_identity_hash(env, self._launch_policy)

        # firefox_user_prefs -> <profile>/user.js (webgl etc. must be set
        # before the browser boots; the sidecar only mkdirs the profile).
        if profile_dir is None:
            # Defensive: the resolver always returns a path, but if it ever
            # does not, allocate a tracked ephemeral dir so stop() still
            # cleans it up instead of leaking it.
            profile_dir = _new_kes_profile()
            self._kes_profile_dir = profile_dir
            _LIVE_KES_DIRS.add(str(profile_dir))
        else:
            profile_dir.mkdir(parents=True, exist_ok=True)
        self._profile_dir = profile_dir
        profile_t0 = time.monotonic()
        try:
            prefs = opts.get("firefox_user_prefs") or {}
            if self._passkey_mode:
                prefs = {**prefs, "marionette.port": self._marionette_port}
            if prefs:
                lines = [f"user_pref({json.dumps(k)}, {json.dumps(v)});" for k, v in prefs.items()]
                (profile_dir / "user.js").write_text("\n".join(lines) + "\n")

            args = [str(_sidecar_bin()), str(camoufox_bin)]
            if not headless:
                args.append("--visible")  # visible window (stealth vs anti-bot)
            args.append(str(profile_dir))
            log_dir = Path(__file__).resolve().parents[2] / "logs"
            log_dir.mkdir(parents=True, exist_ok=True)
            # File lives as long as the child process, not a with-block.
            # Keep stderr diagnostics attributable to one sidecar/session.
            # A shared append-only file made old allocator leaks and unrelated
            # browser deaths look like the current crash, especially when
            # multiple MCP clients were being investigated concurrently.
            self._stderr_path = log_dir / f"kahin-sidecar-{os.getpid()}-{time.time_ns()}.err"
            self._stderr_file = await asyncio.to_thread(open, self._stderr_path, "ab")
            self._process = await asyncio.create_subprocess_exec(
                *args,
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=self._stderr_file,
                env=env,
                limit=_IPC_STREAM_LIMIT,
            )
            self._start_reader()
            # Boot validation: the sidecar must report a live browser. A dead
            # sidecar (or browser that never came up) fails the start.
            health = await self.call("Browser.health")
            if not health.get("alive"):
                raise RuntimeError(
                    "Mirage boot validation failed: Browser.health reports a dead browser"
                )
            # Browser-level proxy (Faz 3 Task 5): Juggler registers a global
            # nsIProtocolProxyChannelFilter, so this routes EVERY channel
            # (all contexts, pages, subframes, workers) through the proxy
            # without touching prefs or env — and it is the only path that
            # carries proxy credentials. `Browser.enable` has already
            # completed (the sidecar performs it before answering health), and
            # no page exists yet, so this lands before the first navigation.
            # Fail closed: a browser that cannot be proxied must not run,
            # otherwise it silently egresses from the host IP.
            if proxy_params is not None:
                try:
                    await self.call("Browser.setBrowserProxy", proxy_params)
                except Exception as exc:  # noqa: BLE001 - fail closed on any error
                    raise RuntimeError(
                        "Mirage proxy application failed; refusing to run without "
                        f"the requested proxy ({type(exc).__name__})"
                    ) from exc
            # The engine is live: anchor uptime (monotonic) and update the
            # per-identity pre-warm metadata. A failure here must never fail
            # boot — record helpers swallow OSError, and the lookup above
            # already tolerated corrupt cache state.
            self._started_monotonic = time.monotonic()
            # One window, one geometry. The browser cannot hold this itself
            # (see _pin_window_geometry); a headed launch gets the geometry
            # pinned on the X11 window for as long as the engine lives.
            self._geometry_task = None
            if not headless and self._process is not None:
                width, height = _window_size()
                logger.info("kahin window pinned to %dx%d (centered)", width, height)
                self._geometry_task = asyncio.create_task(
                    _pin_window_geometry_until_settled(self._process.pid)
                )
            if prewarm_hash is not None:
                hits = (int(prewarm.get("hits", 0)) + 1) if prewarm is not None else 0
                starts = (int(prewarm.get("starts", 0)) + 1) if prewarm is not None else 1
                entry = {
                    "identity_hash": prewarm_hash,
                    "options_ms": round(opts_ms, 1),
                    "profile_ms": round((time.monotonic() - profile_t0) * 1000, 1),
                    "hits": hits,
                    "starts": starts,
                }
                _prewarm_record(prewarm_hash, entry)
                self._prewarm_info = {
                    **entry,
                    "cache": prewarm.get("source", "miss") if prewarm is not None else "miss",
                }
            return EngineContext(
                engine_name=self._engine_name,
                ws_url="",  # IPC over stdio, not WebSocket
                meta={
                    "sidecar": str(_sidecar_bin()),
                    "camoufox": str(camoufox_bin),
                    "transport": "stdio-jsonl",
                },
            )
        except BaseException:
            # asyncio.wait_for(browser_start) cancels start() on a slow boot.
            # Always reap the sidecar in that path; otherwise a retry creates
            # a second Camoufox while the first orphan keeps running.
            await self.stop()
            raise

    def _start_reader(self) -> None:
        """Background task: resolve pending responses, track Juggler sessions
        (attachedToTarget/detachedFromTarget), dispatch events."""

        async def reader() -> None:
            process = self._process
            assert process is not None and process.stdout is not None
            # Read through a local stream, not self._process.stdout: stop()
            # clears self._process before it waits for the sidecar, and the
            # reader must keep draining stdout until real EOF so a large
            # final response cannot fill the pipe and wedge the sidecar.
            stream = process.stdout
            death_reason = "sidecar_stdout_closed"
            try:
                while True:
                    raw = await stream.readline()
                    if not raw:
                        break  # sidecar closed stdout (browser gone)
                    try:
                        data = json.loads(raw)
                    except json.JSONDecodeError:
                        logger.warning("sidecar sent a non-JSON line: %.120s", raw)
                        continue
                    if "id" in data:
                        fut = self._pending.pop(data["id"], None)
                        if fut is not None and not fut.done():
                            if "error" in data:
                                fut.set_exception(RuntimeError(f"CDP error: {data['error']}"))
                            else:
                                fut.set_result(data.get("result", {}))
                    elif "method" in data:
                        # Event metadata is auxiliary state. A malformed
                        # browser event must be logged and dropped, never
                        # allowed to terminate the transport reader while
                        # requests are still in flight.
                        for tracker in (
                            self._track_session,
                            self._track_target_url,
                            self._track_context,
                            self._track_chooser,
                            self._track_screencast,
                            self._track_dom_binding,
                            self._track_network_event,
                            self._track_dialog,
                        ):
                            try:
                                tracker(data)
                            except Exception:  # noqa: BLE001 - one event cannot kill the reader
                                logger.warning("malformed Mirage event metadata in %s", data.get("method"), exc_info=True)
                        evt = EventData(
                            method=data["method"],
                            params=data.get("params", {}),
                            session_id=data.get("sessionId"),
                        )
                        for cb in self._event_callbacks:
                            try:
                                result = cb(evt)
                                if asyncio.iscoroutine(result):
                                    await result
                            except Exception:
                                logger.exception("event callback failed for %s", evt.method)
            except asyncio.CancelledError:
                death_reason = "reader_cancelled"
            except Exception as exc:  # noqa: BLE001
                logger.exception("Mirage reader stopped unexpectedly")
                detail = str(exc).replace("\n", " ")[:160]
                death_reason = f"reader_error:{type(exc).__name__}:{detail}"
            finally:
                # The browser died; fail every in-flight request.
                for fut in self._pending.values():
                    if not fut.done():
                        fut.set_exception(RuntimeError("Mirage sidecar exited"))
                self._pending.clear()
                self._mark_dead(death_reason)

        self._reader = asyncio.create_task(reader())

    def _track_context(self, data: dict[str, Any]) -> None:
        """Maintain sessionId -> {frameId -> executionContextId} (main world).

        Runtime.executionContextCreated carries the frame in auxData.frameId;
        contexts with a name (e.g. __playwright_utility_world__) do NOT map
        to page DOM, so only unnamed (main world) contexts are kept.
        executionContextDestroyed drops the id; executionContextsCleared
        (full navigation) resets the session's map.
        """
        method = data.get("method")
        params = data.get("params", {}) or {}
        sid = data.get("sessionId")
        if method == "Runtime.executionContextCreated":
            ctx_id = params.get("executionContextId")
            aux = params.get("auxData") or {}
            frame_id = aux.get("frameId")
            if not ctx_id or not frame_id or not sid:
                return
            if aux.get("name"):
                return  # utility world — not page DOM
            self._frame_contexts.setdefault(sid, {})[frame_id] = ctx_id
        elif method == "Runtime.executionContextDestroyed":
            ctx_id = params.get("executionContextId")
            if not sid or not ctx_id:
                return
            for frame_id, cid in list(self._frame_contexts.get(sid, {}).items()):
                if cid == ctx_id:
                    del self._frame_contexts[sid][frame_id]
        elif method == "Runtime.executionContextsCleared":
            if sid:
                self._frame_contexts.pop(sid, None)

    def _notify_dialog_change(self) -> None:
        """Wake every reply waiter once; later waiters get a fresh event."""
        changed, self._dialog_changed = self._dialog_changed, asyncio.Event()
        changed.set()

    def _track_dialog(self, data: dict[str, Any]) -> None:
        """Keep sessionId -> open JS dialogs current from Juggler events."""
        method = data.get("method")
        params = data.get("params", {}) or {}
        sid = data.get("sessionId")
        if method in _DIALOG_OPEN_EVENTS:
            dialog_id = params.get("dialogId")
            if not isinstance(sid, str) or not sid or not isinstance(dialog_id, str):
                return
            message = params.get("message")
            self._open_dialogs.setdefault(sid, {})[dialog_id] = {
                "dialogId": dialog_id,
                "type": params.get("type"),
                "message": message[:200] if isinstance(message, str) else None,
                "openedAt": time.time(),
            }
            self._notify_dialog_change()
        elif method in _DIALOG_CLOSE_EVENTS:
            dialog_id = params.get("dialogId")
            dialogs = self._open_dialogs.get(sid or "")
            if dialogs is not None and isinstance(dialog_id, str):
                dialogs.pop(dialog_id, None)
                if not dialogs:
                    self._open_dialogs.pop(sid or "", None)
                self._notify_dialog_change()
        elif method == "Browser.detachedFromTarget":
            session_id = params.get("sessionId") or sid
            if isinstance(session_id, str) and self._open_dialogs.pop(session_id, None):
                self._notify_dialog_change()

    def open_dialogs(self, session_id: str | None = None) -> list[dict[str, Any]]:
        """Open JS dialogs on one session (or every session), oldest first."""
        sessions = [session_id] if session_id is not None else list(self._open_dialogs)
        target_by_session = {sid: tid for tid, sid in self._sessions.items()}
        found: list[dict[str, Any]] = []
        for sid in sessions:
            for info in (self._open_dialogs.get(sid) or {}).values():
                found.append({**info, "sessionId": sid, "targetId": target_by_session.get(sid)})
        found.sort(key=lambda item: item.get("openedAt") or 0.0)
        return found

    async def _await_reply(
        self,
        fut: asyncio.Future[dict[str, Any]],
        method: str,
        sid: str | None,
        timeout: float,
    ) -> dict[str, Any]:
        """Await one reply without letting a JS dialog hold the channel.

        Returns the reply, raises ``TimeoutError`` after ``timeout`` or
        ``_DialogBlocked`` once a dialog on ``sid`` has kept the command
        unanswered past ``_DIALOG_BLOCK_GRACE`` (P2-2: non-blocking dialog
        handling). Browser.* calls carry no session and are never gated.
        """
        loop = asyncio.get_running_loop()
        deadline = loop.time() + timeout
        while True:
            remaining = deadline - loop.time()
            if remaining <= 0:
                raise TimeoutError
            if sid and self._open_dialogs.get(sid):
                try:
                    return await asyncio.wait_for(
                        asyncio.shield(fut), timeout=min(_DIALOG_BLOCK_GRACE, remaining),
                    )
                except TimeoutError:
                    if self._open_dialogs.get(sid):
                        raise _DialogBlocked from None
                    continue  # the dialog closed during the grace window
            changed = self._dialog_changed
            waiter = asyncio.ensure_future(changed.wait())
            try:
                done, _ = await asyncio.wait(
                    {fut, waiter}, timeout=remaining, return_when=asyncio.FIRST_COMPLETED,
                )
            finally:
                waiter.cancel()
            if fut in done:
                return fut.result()

    async def diagnose_stall(
        self,
        method: str,
        session_id: str | None,
        params: dict[str, Any] | None = None,
        *,
        waited_s: float | None = None,
    ) -> dict[str, Any]:
        """Classify why ``method`` got no reply (P0-1).

        Order is evidence strength: a dead transport explains everything; an
        open JS dialog on the session is an observed lock; a Bitwarden FIDO2
        popout or native WebAuthn prompt is an observed pending WebAuthn
        ceremony; otherwise the page itself is busy. Every probe is bounded
        and none of them retries the stalled command.
        """
        diagnosis: dict[str, Any] = {
            "method": method,
            "sessionId": session_id,
            "waitedSeconds": round(waited_s, 2) if isinstance(waited_s, (int, float)) else None,
        }
        process = self._process
        transport_down = (
            self._dead
            or process is None
            or process.returncode is not None
            or self._reader is None
            or self._reader.done()
        )
        if not transport_down:
            try:
                await asyncio.wait_for(self._raw_call("Browser.getInfo", None), timeout=_STALL_PROBE_TIMEOUT)
            except Exception as exc:  # noqa: BLE001 - classification only
                transport_down = True
                diagnosis["browserProbe"] = f"{type(exc).__name__}: {str(exc)[:120]}"
        if transport_down:
            diagnosis.update({
                "cause": "dead_pipe",
                "evidence": {
                    "deathReason": self._death_reason,
                    "returncode": process.returncode if process is not None else None,
                },
                "hint": "The browser transport is gone: kahin_browser_stop, then kahin_browser_start.",
            })
            return diagnosis

        dialogs = self.open_dialogs(session_id) if session_id else self.open_dialogs()
        if dialogs:
            first = dialogs[0]
            diagnosis.update({
                "cause": "pending_js_dialog",
                "evidence": {"dialogs": dialogs},
                "hint": (
                    f"A JS {first.get('type') or 'dialog'} dialog is open on this tab; call "
                    f"kahin_mirage_dialog_accept or kahin_mirage_dialog_dismiss with dialog_id="
                    f"{first.get('dialogId')!r}. Retrying or restarting will not clear it."
                ),
            })
            return diagnosis

        try:
            from kahin import window_inventory  # noqa: PLC0415 - optional Marionette layer

            webauthn = await window_inventory.webauthn_evidence(self, timeout=_STALL_PROBE_TIMEOUT)
        except Exception as exc:  # noqa: BLE001 - classification only
            webauthn = {"pending": None, "error": f"{type(exc).__name__}: {str(exc)[:120]}"}
        if webauthn.get("pending") is True:
            diagnosis.update({
                "cause": "webauthn_pending",
                "evidence": webauthn,
                "hint": (
                    "A WebAuthn ceremony is waiting for a passkey choice. Finish it with "
                    "kahin_vault_login (Bitwarden FIDO2 popout) instead of re-sending page commands."
                ),
            })
            return diagnosis

        probe: str
        if session_id:
            try:
                await asyncio.wait_for(
                    self._raw_call(
                        "Runtime.evaluate",
                        {"expression": "0", "returnByValue": True},
                        session_id=session_id,
                    ),
                    timeout=_STALL_PROBE_TIMEOUT,
                )
                probe = "responsive"
            except Exception:  # noqa: BLE001 - classification only
                probe = "unresponsive"
        else:
            probe = "not_applicable"
        awaited = bool((params or {}).get("awaitPromise"))
        if probe == "responsive" and awaited:
            detail = "awaited_promise_pending"
            hint = (
                "The page answers but the awaited promise never settled. Do not await "
                "long-lived page promises; observe the page instead."
            )
        elif probe == "responsive":
            detail = "slow_command"
            hint = "The page answers simple probes; this command itself is slow. Narrow it or observe first."
        elif probe == "unresponsive":
            detail = "main_thread_blocked"
            hint = (
                "The page does not answer even a trivial probe (long script or an unlisted modal). "
                "Inspect kahin_agent_status windows before acting again."
            )
        else:
            detail = "browser_command_slow"
            hint = "A browser-level command did not answer; inspect kahin_engine_health."
        diagnosis.update({
            "cause": "page_busy",
            "evidence": {"detail": detail, "pageProbe": probe, "webauthn": webauthn},
            "hint": hint,
        })
        return diagnosis

    def resolve_context(self, frame_id: str, session_id: str | None = None) -> str | None:
        """Main-world executionContextId for a frame on a live target.

        Multi-step actions pass the session captured at their start. The
        selected-target fallback remains for one-shot legacy callers.
        """
        sid = session_id or self._sessions.get(self._current_target or "")
        if not sid:
            return None
        return self._frame_contexts.get(sid, {}).get(frame_id)

    async def install_dom_stream(self, init_script: str) -> None:
        """Install the browser-native binding and init script once.

        Browser-level Juggler methods are used so the observer follows newly
        created tabs and navigated frames. The caller still evaluates the
        script in the current frame because init scripts only affect future
        documents.
        """
        if not self._dom_binding_installed:
            await self.call("Browser.addBinding", {
                "name": DOM_STREAM_BINDING_NAME,
                "script": "function() {}",
            })
            self._dom_binding_installed = True
        if not self._dom_init_script_installed:
            await self.call("Browser.setInitScripts", {
                "scripts": [{"script": init_script}],
            })
            self._dom_init_script_installed = True

    async def wait_for_dom_signal(self, timeout: float) -> bool:
        """Wait until the page reports a DOM mutation through the binding."""
        try:
            await asyncio.wait_for(self._dom_signal.wait(), timeout=timeout)
            return True
        except asyncio.TimeoutError:
            return False
        finally:
            self._dom_signal.clear()

    def _track_dom_binding(self, data: dict[str, Any]) -> None:
        """Wake DOM stream consumers without copying page payloads."""
        if data.get("method") != "Page.bindingCalled":
            return
        params = data.get("params", {}) or {}
        if params.get("name") == DOM_STREAM_BINDING_NAME:
            self._dom_signal.set()

    def _track_network_event(self, data: dict[str, Any]) -> None:
        """Buffer bounded Network events for one-shot route decisions.

        The sidecar schema deliberately has no ``requestIntercepted`` event;
        interception is marked on ``Network.requestWillBeSent``. The raw
        params are retained so the native continuation helpers receive the
        exact request/session identifiers emitted by the browser.
        """
        method = data.get("method")
        params = data.get("params")
        if not isinstance(method, str) or not method.startswith("Network.") or not isinstance(params, dict):
            return
        self._network_events.append({
            "method": method,
            "params": params,
            "session_id": data.get("sessionId"),
            "_kahin_received_at": time.monotonic(),
        })
        self._network_signal.set()

    async def wait_for_intercepted(
        self,
        predicate: Callable[[dict[str, Any]], bool],
        timeout: float,
        *,
        after_monotonic: float | None = None,
    ) -> dict[str, Any] | None:
        """Wait for a fresh intercepted Network event matching ``predicate``.

        The engine keeps a bounded event window for diagnostics. Route calls
        must not accidentally consume an older paused request from that
        window, so callers can provide the monotonic start of their one-shot
        wait.
        """
        loop = asyncio.get_running_loop()
        deadline = loop.time() + max(0.0, timeout)
        while True:
            events = list(self._network_events)
            for event in events:
                if event.get("method") != "Network.requestWillBeSent":
                    continue
                received_at = event.get("_kahin_received_at")
                if after_monotonic is not None and (
                    not isinstance(received_at, (int, float)) or received_at < after_monotonic
                ):
                    continue
                params = event.get("params") or {}
                request_id = params.get("requestId")
                if not isinstance(request_id, str) or request_id in self._network_routed_ids:
                    continue
                if params.get("isIntercepted") is True and predicate(event):
                    self._network_routed_ids.add(request_id)
                    # Keep the dedupe set in step with the bounded deque:
                    # once the window is full, older events are stale anyway.
                    if len(self._network_routed_ids) > self._network_events.maxlen:
                        self._network_events.clear()
                        self._network_routed_ids.clear()
                    return event
            remaining = deadline - loop.time()
            if remaining <= 0:
                return None
            try:
                await asyncio.wait_for(self._network_signal.wait(), timeout=min(remaining, 0.25))
            except asyncio.TimeoutError:
                pass
            finally:
                self._network_signal.clear()

    def _track_chooser(self, data: dict[str, Any]) -> None:
        """Record Page.fileChooserOpened (file input clicked while
        Page.setInterceptFileChooserDialog is enabled) into the bounded
        per-session queue and set the event so wait_for_chooser can consume
        it (Gap C)."""
        if data.get("method") == "Page.fileChooserOpened":
            params = data.get("params", {}) or {}
            session_id = data.get("sessionId")
            owner = session_id if isinstance(session_id, str) else None
            self._pending_choosers.append((owner, params))
            self._chooser_event.set()

    async def wait_for_chooser(
        self, timeout: float, *, session_id: str | None = None,
    ) -> dict[str, Any] | None:
        """Return the fileChooserOpened params, waiting up to ``timeout`` for
        one when nothing is pending yet; None on timeout.

        Covers both orders: the input was already clicked (pending chooser is
        returned immediately) or the click will come after this call. When a
        session is supplied, only that tab's chooser can be consumed; events
        from another tab remain queued for their owner.
        """
        deadline = asyncio.get_running_loop().time() + max(0.0, timeout)
        while True:
            for index, (owner, chooser) in enumerate(self._pending_choosers):
                if session_id is not None and owner != session_id:
                    continue
                del self._pending_choosers[index]
                if not self._pending_choosers:
                    self._chooser_event.clear()
                # sessionId belongs to the event envelope, not to the Juggler
                # params. Keep it private so upload_files can route the
                # chooser to the page that actually opened it.
                if owner is not None:
                    return {**chooser, "_kahinSessionId": owner}
                return chooser
            remaining = deadline - asyncio.get_running_loop().time()
            if remaining <= 0:
                return None
            self._chooser_event.clear()
            try:
                await asyncio.wait_for(self._chooser_event.wait(), timeout=remaining)
            except asyncio.TimeoutError:
                return None

    def _track_screencast(self, data: dict[str, Any]) -> None:
        """Queue Page.screencastFrame params (Gap D live screencast).

        The frame's ``data`` is a base64-encoded JPEG (Camoufox encodes
        JPEG, not PNG — nsScreencastService.cpp). Frames are queued BEFORE
        the client acks them; camoufox's kMaxFramesInFlight=1 stalls the
        stream when an ack is missing, so every consumed frame must be
        ack'd (the screencast_frame tool does this via
        Page.screencastFrameAck). The event params carry no screencastId —
        the stream id is remembered from Page.startScreencast.
        """
        if data.get("method") == "Page.screencastFrame":
            params = data.get("params", {}) or {}
            event_session = data.get("sessionId")
            expected_session = self._screencast_session_id or self._screencast_starting_session_id
            # Accept old sidecars that omitted the event envelope's sessionId,
            # but never mix frames from two explicitly identified tabs.
            # Once a stream has an owning session, an ownerless event is not
            # safe to accept: it could have come from another tab after a
            # concurrent switch. The current sidecar carries sessionId on
            # forwarded Page events; fail closed if a future sidecar drops it.
            owned = expected_session is None or event_session == expected_session
            if params.get("data") and owned and (self._screencast_id is not None or self._screencast_starting):
                self._screencast_frames.append({
                    **params,
                    "_kahinScreencastGeneration": self._screencast_generation,
                })
                self._screencast_event.set()

    async def wait_for_screencast_frame(
        self,
        timeout: float,
        *,
        generation: int | None = None,
    ) -> dict[str, Any] | None:
        """Return the OLDEST pending screencastFrame params (base64-JPEG in
        ``data``), waiting up to ``timeout`` when nothing is queued yet;
        None on timeout. A frame stays queued until this consumes it — the
        caller must then Page.screencastFrameAck its stream id (mismatched
        ids are a no-op on Camoufox). The queue keeps up to 64 unacked
        frames, so a slow consumer sees the oldest one first.
        """
        loop = asyncio.get_running_loop()
        deadline = loop.time() + max(0.0, timeout)
        while True:
            while self._screencast_frames:
                frame = self._screencast_frames.popleft()
                if generation is None or frame.get("_kahinScreencastGeneration") == generation:
                    if not self._screencast_frames:
                        self._screencast_event.clear()
                    return frame
            if generation is not None and generation != self._screencast_generation:
                return None
            remaining = deadline - loop.time()
            if remaining <= 0:
                return None
            try:
                await asyncio.wait_for(self._screencast_event.wait(), timeout=remaining)
            except asyncio.TimeoutError:
                return None
            # stop() wakes this event after clearing the queue. Do not turn
            # that liveness wake-up into a deque underflow or a fake frame.
            if not self._screencast_frames:
                if not self.is_alive():
                    return None
                if self._screencast_id is None and not self._screencast_starting:
                    return None
                self._screencast_event.clear()

    def drain_screencast_frames(self) -> int:
        """Discard queued frames before a caller requests a fresh capture.

        The caller must ACK the returned count before waiting again; frames
        are held by Camoufox until their acknowledgements arrive.
        """
        discarded = len(self._screencast_frames)
        self._screencast_frames.clear()
        self._screencast_event.clear()
        return discarded

    def screencast_pending(self) -> dict[str, Any]:
        """Unacked frame count + newest frame summary + stream id — stream
        health: pending > 0 while frames wait for their ack (Camoufox holds
        at kMaxFramesInFlight=1 unacked frames, so a long-lived non-zero
        count means the consumer stalled)."""
        last = self._screencast_frames[-1] if self._screencast_frames else None
        return {
            "pending": len(self._screencast_frames),
            "screencastId": self._screencast_id,
            "active": self._screencast_id is not None,
            "last": {
                "deviceWidth": last.get("deviceWidth"),
                "deviceHeight": last.get("deviceHeight"),
                "dataLength": len(last.get("data", "")),
            }
            if last
            else None,
        }

    def set_screencast_id(self, screencast_id: str) -> None:
        """Remember the stream id returned by Page.startScreencast so the
        frame tool can ack frames whose event carries no id."""
        self._screencast_id = screencast_id

    @property
    def screencast_session_id(self) -> str | None:
        """Session owning the active stream; used for cross-tab ACK/stop."""
        return self._screencast_session_id

    def clear_screencast(self, *, wake_waiters: bool = False) -> int:
        """Drop all queued frames + the stream id (used on stopScreencast so
        no stale frame survives the stream); returns the discarded count.
        A stop operation wakes consumers so they cannot wait for a frame from
        a stream that has already ended.
        """
        discarded = len(self._screencast_frames)
        self._screencast_frames.clear()
        self._screencast_generation += 1
        if wake_waiters:
            self._screencast_event.set()
        else:
            self._screencast_event.clear()
        self._screencast_id = None
        self._screencast_session_id = None
        self._screencast_starting_session_id = None
        return discarded

    @property
    def screencast_generation(self) -> int:
        """Monotonic stream lifetime token for concurrent frame consumers."""
        return self._screencast_generation

    def get_current_target(self, caller_id: str | None = None) -> str | None:
        """Return the active target for the caller, or default current target."""
        from kahin.subagent import get_active_subagent_context
        ctx = get_active_subagent_context()
        cid = caller_id or ctx.get("caller_id")
        tid = ctx.get("target_id")
        if tid and tid in self._sessions:
            return tid
        if cid and cid in self._agent_targets:
            assigned = self._agent_targets[cid]
            if assigned in self._sessions:
                return assigned
        return self._current_target

    def current_session_id(self, caller_id: str | None = None) -> str | None:
        """Return the Juggler session owning the selected target."""
        target = self.get_current_target(caller_id=caller_id)
        return self._sessions.get(target or "")

    def current_browser_context_id(self, caller_id: str | None = None) -> str | None:
        """Return the selected target's browser context, if it has one."""
        from kahin.subagent import get_active_subagent_context
        ctx = get_active_subagent_context()
        cid = caller_id or ctx.get("caller_id")
        tid = ctx.get("target_id")
        if tid:
            info = self._target_infos.get(tid) or {}
            value = info.get("browserContextId")
            if isinstance(value, str) and value:
                return value
        if cid:
            if cid in self._agent_contexts:
                return self._agent_contexts[cid]
            if cid in self._agent_targets:
                info = self._target_infos.get(self._agent_targets[cid]) or {}
                value = info.get("browserContextId")
                if isinstance(value, str) and value:
                    return value
        target = self.get_current_target(caller_id=cid)
        info = self._target_infos.get(target or "") or {}
        value = info.get("browserContextId")
        return value if isinstance(value, str) and value else None

    def frame_id_for_execution_context(self, session_id: str, context_id: Any) -> str | None:
        """Resolve a file-chooser execution context to its live frame id."""
        for frame_id, known_context in self._frame_contexts.get(session_id, {}).items():
            if str(known_context) == str(context_id):
                return frame_id
        return None

    def _track_session(self, data: dict[str, Any]) -> None:
        """Update the targetId -> sessionId map from Juggler target events."""
        method = data.get("method")
        params = data.get("params", {}) or {}
        if method == "Browser.attachedToTarget":
            target_info = params.get("targetInfo") or {}
            target_id = target_info.get("targetId") or params.get("targetId")
            session_id = params.get("sessionId") or data.get("sessionId")
            if target_id and session_id:
                # Re-attaching a target creates a new execution-session
                # lifetime. Never let contexts from either the old binding or
                # a reused session id resolve in the new document.
                old_session_id = self._sessions.get(target_id)
                if old_session_id:
                    self._frame_contexts.pop(old_session_id, None)
                self._frame_contexts.pop(session_id, None)
                self._sessions[target_id] = session_id
                self._target_infos[target_id] = dict(target_info)
        elif method == "Browser.detachedFromTarget":
            target_id = params.get("targetId")
            session_id = params.get("sessionId") or data.get("sessionId")
            # An ownerless detach cannot be safely associated with a target:
            # the target may already have been reattached with a new session.
            # Keeping the mapping is safer than deleting a live replacement.
            if not isinstance(session_id, str) or not session_id:
                return
            # A target can be reattached before the old detach event reaches
            # the reader. That old event must not delete the new session.
            if target_id and session_id:
                current_session = self._sessions.get(target_id)
                if current_session is not None and current_session != session_id:
                    return
            self._frame_contexts.pop(session_id, None)
            if not target_id:
                target_id = next(
                    (tid for tid, sid in self._sessions.items() if sid == session_id),
                    None,
                )
            if target_id:
                self._sessions.pop(target_id, None)
                self._target_infos.pop(target_id, None)
                if self._current_target == target_id:
                    self._current_target = next(iter(self._sessions), None)

    def _track_target_url(self, data: dict[str, Any]) -> None:
        """Keep CDP-shaped Target.getTargets URL data current."""
        if data.get("method") not in {"Page.navigationCommitted", "Page.sameDocumentNavigation"}:
            return
        session_id = data.get("sessionId")
        url = (data.get("params") or {}).get("url")
        if not isinstance(session_id, str) or not isinstance(url, str):
            return
        target_id = next(
            (tid for tid, sid in self._sessions.items() if sid == session_id),
            None,
        )
        if target_id is not None:
            self._target_infos.setdefault(target_id, {}).update({"url": url})

    async def call(
        self, method: str, params: dict[str, Any] | None = None, session_id: str | None = None
    ) -> dict[str, Any]:
        """Send one Juggler ``Domain.method`` and await its id-matched reply.

        Page-scoped methods carry the current target's sessionId unless an
        explicit session_id is given (Browser.* methods stay on the root
        session). Dead engines raise immediately instead of hanging.
        """
        if self._dead:
            raise RuntimeError("Mirage is dead")
        if self._process is None or self._process.stdin is None:
            raise RuntimeError("Mirage not started")
        async with self._target_lock:
            sid = session_id
            if sid is None and not method.startswith("Browser."):
                sid = self.current_session_id()
        if method == "Page.setInterceptFileChooserDialog":
            # A new interception mode starts a new chooser lifetime. Clear a
            # chooser event from a previous page/action before sending the
            # real Juggler command; events emitted afterwards remain visible.
            self._pending_choosers.clear()
            self._chooser_event.clear()
        if method == "Page.startScreencast":
            # Clear the predecessor before the real start call. Frames emitted
            # by the new stream while its reply is in flight must remain queued.
            self.clear_screencast()
            self._screencast_starting = True
            self._screencast_starting_session_id = sid
        loop = asyncio.get_running_loop()
        started = loop.time()
        response_timeout = (
            _PAGE_NAVIGATE_RESPONSE_TIMEOUT
            if method == "Page.navigate"
            else _REQUEST_TIMEOUT
        )
        request_id: int | None = None
        caller_name: str | None = None
        if sid:
            tid = next((t for t, s in self._sessions.items() if s == sid), None)
            if tid:
                caller_name = next((c for c, t in self._agent_targets.items() if t == tid), None)
        if not caller_name:
            try:
                from kahin.subagent import get_active_subagent_context
                caller_name = get_active_subagent_context().get("caller_id")
            except Exception:
                caller_name = None

        if caller_name:
            self._agent_in_flight[caller_name] = self._agent_in_flight.get(caller_name, 0) + 1
            self._agent_last_seen[caller_name] = started
        try:
            request_id, fut = await self._send(method, params, sid)
            result = await self._await_reply(fut, method, sid, response_timeout)
            if method == "Page.startScreencast":
                screencast_id = result.get("screencastId")
                if isinstance(screencast_id, str) and screencast_id:
                    self.set_screencast_id(screencast_id)
                    self._screencast_session_id = sid
                self._screencast_starting = False
                self._screencast_starting_session_id = None
            return result
        except (TimeoutError, _DialogBlocked) as exc:
            if method == "Page.startScreencast":
                self._screencast_starting = False
                self._screencast_starting_session_id = None
            if request_id is not None:
                self._pending.pop(request_id, None)
            waited = loop.time() - started
            # P0-1: never answer a stall with a bare timeout. The cause decides
            # the recovery (dialog -> handle it, WebAuthn -> finish it, dead
            # pipe -> restart); a longer timeout fixes none of them.
            diagnosis = await self.diagnose_stall(method, sid, params, waited_s=waited)
            cause = diagnosis.get("cause") or "page_busy"
            self._last_stall = (time.monotonic(), diagnosis)
            if isinstance(exc, _DialogBlocked):
                message = (
                    f"Mirage: {method} blocked by an open JS dialog after {waited:.1f}s "
                    f"[cause={cause}]"
                )
            else:
                message = f"Mirage: response timeout ({response_timeout:.1f}s) for {method} [cause={cause}]"
            raise MirageCommandTimeout(message, diagnosis) from None
        except BaseException:
            if method == "Page.startScreencast":
                self._screencast_starting = False
                self._screencast_starting_session_id = None
            if request_id is not None:
                self._pending.pop(request_id, None)
            raise
        finally:
            if caller_name:
                self._agent_in_flight[caller_name] = max(0, self._agent_in_flight.get(caller_name, 1) - 1)
                try:
                    self._agent_last_seen[caller_name] = asyncio.get_running_loop().time()
                except RuntimeError:
                    pass

    async def _send(
        self, method: str, params: dict[str, Any] | None, sid: str | None,
    ) -> tuple[int, asyncio.Future[dict[str, Any]]]:
        """Write one JSONL request; return its id and reply future."""
        self._msg_id += 1
        request_id = self._msg_id
        msg: dict[str, Any] = {"id": request_id, "method": method, "params": params or {}}
        if sid:
            msg["sessionId"] = sid
        fut: asyncio.Future[dict[str, Any]] = asyncio.get_running_loop().create_future()
        self._pending[request_id] = fut
        try:
            # Keep JSONL records intact when several MCP calls arrive at once;
            # pending replies remain fully concurrent behind this tiny write
            # critical section.
            async with self._write_lock:
                if self._process is None or self._process.stdin is None:
                    raise RuntimeError("Mirage not started")
                self._process.stdin.write((json.dumps(msg) + "\n").encode())
                try:
                    await asyncio.wait_for(self._process.stdin.drain(), timeout=_IPC_WRITE_TIMEOUT)
                except asyncio.TimeoutError as exc:
                    self._mark_dead("stdin_write_timeout")
                    raise RuntimeError(
                        f"Mirage: stdin write timeout ({_IPC_WRITE_TIMEOUT:.1f}s); sidecar is not draining"
                    ) from exc
        except BaseException:
            self._pending.pop(request_id, None)
            raise
        return request_id, fut

    async def _raw_call(
        self, method: str, params: dict[str, Any] | None, session_id: str | None = None,
    ) -> dict[str, Any]:
        """Probe path: explicit session, no dialog gate, no diagnosis.

        Callers bound it with ``asyncio.wait_for``; the pending slot is freed
        on every exit so an unanswered probe never leaks.
        """
        if self._dead or self._process is None or self._process.stdin is None:
            raise RuntimeError("Mirage is dead")
        request_id, fut = await self._send(method, params, session_id)
        try:
            return await fut
        finally:
            self._pending.pop(request_id, None)

    async def get_response_body(
        self, request_id: str, session_id: str | None = None,
    ) -> dict[str, Any]:
        """Read a response body with a bounded completion-race retry.

        Juggler may emit ``requestWillBeSent`` before the response body is
        queryable.  CDP callers commonly receive that request id from an
        event and ask for the body immediately, so a single native call can
        fail transiently even though the request is healthy.  Retry only
        native protocol errors and keep the total wait bounded; transport or
        liveness failures still fail immediately.
        """
        loop = asyncio.get_running_loop()
        deadline = loop.time() + _RESPONSE_BODY_RETRY_TIMEOUT
        while True:
            try:
                return await self.call(
                    "Network.getResponseBody",
                    {"requestId": request_id},
                    session_id=session_id,
                )
            except RuntimeError as exc:
                if "cdp error:" not in str(exc).lower():
                    raise
                remaining = deadline - loop.time()
                if remaining <= 0:
                    raise
                await asyncio.sleep(min(_RESPONSE_BODY_RETRY_INTERVAL, remaining))

    # --- session management (Juggler target model) ---

    async def create_page(self, url: str = "about:blank", browser_context_id: str | None = None) -> dict[str, Any]:
        """Open a new tab; returns {"targetId", "sessionId"} and makes it current.

        The sessionId is learned from the Browser.attachedToTarget event the
        sidecar forwards right after Browser.newPage's reply.
        """
        # Juggler's Browser.newPage already creates an about:blank document;
        # sending a synthetic second Page.navigate to that same URL leaves a
        # fresh target with a competing navigation in flight. The next real
        # navigation can then be aborted or wait for the sidecar deadline.
        # Keep the default tab creation a pure attach, and only ask the
        # sidecar's combined flow to navigate when the caller supplied a real
        # destination.
        params: dict[str, Any] = {}
        if url and url != "about:blank":
            params["url"] = url
        if browser_context_id:
            params["browserContextId"] = browser_context_id
        result = await self.call("Browser.newPage", params)
        target_id = result.get("targetId")
        if not target_id:
            raise RuntimeError(f"Browser.newPage returned no targetId: {result}")
        loop = asyncio.get_running_loop()
        deadline = loop.time() + min(_REQUEST_TIMEOUT, 10.0)
        while target_id not in self._sessions:
            if loop.time() > deadline:
                raise RuntimeError(f"session for target {target_id} never attached")
            await asyncio.sleep(0.05)
        async with self._target_lock:
            if target_id not in self._sessions:
                raise RuntimeError(f"target {target_id} detached before it became current")
            self._current_target = target_id
            session_id = self._sessions[target_id]
        await self._wait_for_page_frame(session_id, deadline=min(deadline, loop.time() + 3.0))
        # Reflect runtime user-agent override onto DOM prototype for newly created pages
        ua = self._user_agent_overrides.get(browser_context_id or "") or self._user_agent_overrides.get("default")
        if ua:
            js = f"try {{ Object.defineProperty(Navigator.prototype, 'userAgent', {{ get: () => {json.dumps(ua)}, configurable: true }}); }} catch (e) {{}}"
            try:
                await self.call("Runtime.evaluate", {"expression": js}, session_id=session_id)
            except Exception:
                pass
        return {"targetId": target_id, "sessionId": session_id}

    async def _wait_for_page_frame(self, session_id: str, *, deadline: float) -> None:
        """Wait until the sidecar has registered a main frame for a target.

        ``Browser.attachedToTarget`` can precede the initial
        ``Page.frameAttached``/execution-context events. Returning a new tab
        in that gap makes an immediate Page.navigate race the target's
        about:blank lifecycle and can leave the Juggler navigation promise
        pending for its full 30-second deadline.
        """
        loop = asyncio.get_running_loop()
        while loop.time() < deadline:
            try:
                tree = await asyncio.wait_for(
                    self.call("Page.getFrameTree", session_id=session_id),
                    timeout=min(0.5, max(0.05, deadline - loop.time())),
                )
            except Exception:
                tree = None
            frame_tree = tree.get("frameTree") if isinstance(tree, dict) else None
            frame = frame_tree.get("frame") if isinstance(frame_tree, dict) else None
            if isinstance(frame, dict) and isinstance(frame.get("id"), str) and frame["id"]:
                return
            await asyncio.sleep(0.05)
        raise RuntimeError("new page frame did not become ready before the bounded deadline")

    async def ensure_page(
        self,
        caller_id: str | None = None,
        target_id: str | None = None,
    ) -> dict[str, Any]:
        """Return the caller's tab/context, creating one lazily inside this browser.

        Browser startup intentionally does not create a second process or an
        eager throw-away page. The first page-oriented operation gets one
        about:blank tab, and subsequent operations reuse it. Subagents with distinct
        caller identities receive their own dedicated tab and isolated browser context.
        """
        from kahin.subagent import get_active_subagent_context
        ctx = get_active_subagent_context()
        cid = caller_id or ctx.get("caller_id")
        tid = target_id or ctx.get("target_id")

        async with self._page_lock:
            # 1. Explicit target requested
            if tid and tid in self._sessions:
                return {"targetId": tid, "sessionId": self._sessions[tid]}

            # 2. Caller has an existing active tab
            if cid and cid in self._agent_targets:
                assigned = self._agent_targets[cid]
                if assigned in self._sessions:
                    self._agent_last_seen[cid] = asyncio.get_running_loop().time()
                    return {"targetId": assigned, "sessionId": self._sessions[assigned]}

            # 3. First caller adopts the initial boot window if nothing assigned yet
            if not self._sessions and not self._agent_targets:
                adopted = await self._adopt_existing_window()
                if adopted is not None:
                    if cid:
                        self._agent_targets[cid] = adopted["targetId"]
                    return adopted

            # 4. If this is a specific caller/subagent, allocate a dedicated tab
            # inside an isolated browser context (single Camoufox process)!
            if cid:
                self._agent_last_seen[cid] = asyncio.get_running_loop().time()
                await self._prune_zombie_contexts()
                browser_ctx_id = None
                try:
                    ctx_res = await self.call("Browser.createBrowserContext", {})
                    browser_ctx_id = ctx_res.get("browserContextId")
                    if browser_ctx_id:
                        self._agent_contexts[cid] = browser_ctx_id
                except Exception:
                    pass
                created = await self.create_page("about:blank", browser_context_id=browser_ctx_id)
                self._agent_targets[cid] = created["targetId"]
                return created

            # 5. Default fallback for callers without agent identity
            if self._current_target in self._sessions:
                return {
                    "targetId": self._current_target,
                    "sessionId": self._sessions[self._current_target],
                }
            if self._sessions:
                async with self._target_lock:
                    self._current_target = next(iter(self._sessions))
                    target_id_val = self._current_target
                return {"targetId": target_id_val, "sessionId": self._sessions[target_id_val]}
            adopted = await self._adopt_existing_window()
            if adopted is not None:
                return adopted
            return await self.create_page("about:blank")

    async def _prune_zombie_contexts(self, *, force_cap: bool = False) -> None:
        """Reap genuine zombie tabs and isolated browser contexts without false positives.

        Guarantees:
        1. An agent with ANY operation in flight (_agent_in_flight > 0) is NEVER evicted.
        2. Clean up callers whose targets detached or closed in Camoufox.
        3. Clean up callers with confirmed dead PIDs (ProcessLookupError via os.kill).
        4. Idle reaping applies ONLY when in_flight == 0 and idle time exceeds safety TTL.
        5. Respects N-parallelism: no arbitrary ceiling killing live working subagents.
        """
        try:
            loop = asyncio.get_running_loop()
            now = loop.time()
        except RuntimeError:
            return
        to_evict: list[str] = []

        # 1. Clean up callers whose targets detached or no longer exist in self._sessions
        for caller, tid in list(self._agent_targets.items()):
            if tid not in self._sessions:
                to_evict.append(caller)

        # 2. Check callers with PID-based identities whose parent/harness process died
        for caller in list(self._agent_targets.keys()):
            if caller in to_evict or self._agent_in_flight.get(caller, 0) > 0:
                continue
            import re
            m = re.search(r"(?:proc_|pid[_-])(\d+)", caller)
            if m:
                pid = int(m.group(1))
                try:
                    os.kill(pid, 0)
                except ProcessLookupError:
                    # Parent process confirmed dead -> 100% verified zombie
                    to_evict.append(caller)
                except (PermissionError, OSError):
                    pass

        # 3. Idle timeout check: ONLY applies if in_flight == 0 (never kill running operations)
        ttl_env = os.environ.get("KAHIN_SUBAGENT_IDLE_TTL")
        ttl_seconds = float(ttl_env) if ttl_env else _DEFAULT_SUBAGENT_IDLE_TTL
        for caller, last_seen in list(self._agent_last_seen.items()):
            if caller in to_evict:
                continue
            if self._agent_in_flight.get(caller, 0) > 0:
                # Active operation in flight -> protected against reap
                continue
            if (now - last_seen) > ttl_seconds:
                to_evict.append(caller)

        # 4. Optional user-configured max cap (0 = unlimited / pure N-parallel)
        max_subagents_env = int(os.environ.get("KAHIN_MAX_SUBAGENTS", "0"))
        if max_subagents_env > 0:
            active_survivors = [c for c in self._agent_targets if c not in to_evict]
            if len(active_survivors) >= max_subagents_env or force_cap:
                # Evict only truly idle callers with ZERO operations in flight
                idle_survivors = [
                    c for c in active_survivors
                    if self._agent_in_flight.get(c, 0) == 0
                ]
                idle_survivors.sort(key=lambda c: self._agent_last_seen.get(c, 0.0))
                excess = max(0, len(active_survivors) - (max_subagents_env - 1))
                for caller in idle_survivors[:excess]:
                    to_evict.append(caller)

        for caller in set(to_evict):
            tid = self._agent_targets.pop(caller, None)
            ctx = self._agent_contexts.pop(caller, None)
            self._agent_last_seen.pop(caller, None)
            self._agent_in_flight.pop(caller, None)
            if tid and tid in self._sessions:
                try:
                    sid = self._sessions.get(tid)
                    if sid:
                        await self.call("Page.close", {}, session_id=sid)
                except Exception:
                    pass
            if ctx:
                try:
                    await self.call("Browser.removeBrowserContext", {"browserContextId": ctx})
                except Exception:
                    pass

    async def _adopt_existing_window(self) -> dict[str, Any] | None:
        """Adopt the window Camoufox already opened at boot instead of opening
        a second one via Browser.newPage (Juggler newPage creates a fresh
        toplevel window, one tab per window).

        The boot window is not announced through attachedToTarget, so
        _sessions stays empty. Probe Target.getTargets and attach to the
        first page target ourselves so no second window is ever spawned.
        """
        for _ in range(10):
            try:
                result = await self.call("Target.getTargets", {})
            except Exception:
                result = None
            infos = (result or {}).get("targetInfos") or []
            if infos:
                break
            await asyncio.sleep(0.1)
        for info in infos:
            tid = info.get("targetId")
            if not isinstance(tid, str) or tid in self._sessions:
                continue
            info_type = info.get("type")
            if info_type not in (None, "page"):
                continue
            try:
                await self.call("Target.attachToTarget", {"targetId": tid})
            except Exception:
                continue
            sid = self._sessions.get(tid)
            if not sid:
                continue
            async with self._target_lock:
                self._current_target = tid
            return {"targetId": tid, "sessionId": sid}
        return None

    async def close_page(self, target_id: str) -> dict[str, Any]:
        """Close a tab (Page.close) and forget its Juggler session."""
        session_id = self._sessions.get(target_id)
        if session_id is None:
            raise RuntimeError(f"unknown target: {target_id}")
        await self.call("Page.close", session_id=session_id)
        loop = asyncio.get_running_loop()
        deadline = loop.time() + 2.0
        while target_id in self._sessions:
            if loop.time() > deadline:
                raise RuntimeError(f"target {target_id} did not detach after Page.close")
            await asyncio.sleep(0.05)
        contexts_to_remove: list[str] = []
        async with self._target_lock:
            # The detach event owns removal. Never manufacture a successful
            # close by deleting a still-live session from Python state.
            if target_id in self._sessions:
                raise RuntimeError(f"target {target_id} did not detach after Page.close")
            for k, v in list(self._agent_targets.items()):
                if v == target_id:
                    self._agent_targets.pop(k, None)
                    ctx = self._agent_contexts.pop(k, None)
                    if ctx:
                        contexts_to_remove.append(ctx)
            if self._current_target == target_id:
                self._current_target = next(iter(self._sessions), None)
        for ctx in contexts_to_remove:
            try:
                await self.call("Browser.removeBrowserContext", {"browserContextId": ctx})
            except Exception:
                pass
        return {"closed": target_id}

    async def switch_page(self, target_id: str) -> dict[str, Any]:
        """Route page-scoped calls to an existing tab."""
        async with self._target_lock:
            if target_id not in self._sessions:
                raise RuntimeError(f"unknown target: {target_id}")
            from kahin.subagent import get_active_subagent_context
            ctx = get_active_subagent_context()
            cid = ctx.get("caller_id")
            if cid:
                self._agent_targets[cid] = target_id
            self._current_target = target_id
        return {"switched": target_id}

    async def list_pages(self) -> list[dict[str, Any]]:
        """All known tabs with their Juggler session ids."""
        active_tid = self.get_current_target()
        return [
            {"targetId": tid, "sessionId": sid, "current": tid == active_tid}
            for tid, sid in self._sessions.items()
        ]

    async def execute_cdp(
        self,
        domain: str,
        command: str,
        params: dict[str, Any] | None = None,
        session_id: str | None = None,
    ) -> dict[str, Any]:
        """Execute a CDP-shaped request through the Mirage equivalent.

        Agents often know the Chrome/CDP surface better than the Juggler
        tool names. Keep that request surface working on Camoufox while
        routing the operation to the real Juggler method or tab primitive.
        The returned object stays CDP-shaped, so callers do not need to know
        that the implementation used Mirage.
        """
        p = dict(params or {})
        page_session_id = session_id
        if page_session_id is None and _needs_mirage_page_for_adapter(domain, command):
            page = await self.ensure_page()
            page_session_id = page.get("sessionId")
        method = f"{domain}.{command}"

        # These domains are event-driven in Juggler and do not need an
        # enable/disable handshake. Treat the CDP setup calls as successful
        # no-ops so a raw CDP client can keep its normal bootstrap sequence.
        if method in {
            "Page.enable",
            "Page.disable",
            "Runtime.enable",
            "Runtime.disable",
            "Network.enable",
            "Network.disable",
            "DOM.enable",
            "DOM.disable",
            "Accessibility.enable",
            "Accessibility.disable",
        }:
            return {}

        if domain == "Target":
            return await self._execute_cdp_target(command, p)
        if domain == "Input":
            return await self._execute_cdp_input(command, p, page_session_id)
        if domain == "Emulation":
            return await self._execute_cdp_emulation(command, p, page_session_id)
        if domain == "Network":
            return await self._execute_cdp_network(command, p, page_session_id)
        if domain == "Browser" and command == "getVersion":
            result = await self.call("Browser.getInfo", p)
            return {
                "protocolVersion": result.get("protocolVersion", ""),
                "product": result.get("product", result.get("userAgent", "")),
                "revision": result.get("revision", ""),
                "userAgent": result.get("userAgent", ""),
                "jsVersion": result.get("jsVersion", ""),
            }

        if domain == "Page" and command == "captureScreenshot":
            result = await self.call("Page.captureScreenshot", p, session_id=page_session_id)
            data = result.get("data")
            if not isinstance(data, str) or not data.strip():
                raise RuntimeError(f"Page.captureScreenshot returned no data: {result}")
            return {"data": data}
        if domain == "Page" and command == "getLayoutMetrics":
            return await self._execute_cdp_layout_metrics(page_session_id)
        if domain == "Page" and command == "stopLoading":
            await self.call(
                "Runtime.evaluate", {"expression": "window.stop()"}, session_id=page_session_id,
            )
            return {}
        if domain == "Page" and command == "stopScreencast":
            result = await self.call(
                "Page.stopScreencast", p, session_id=self.screencast_session_id or page_session_id,
            )
            result = dict(result)
            result["discardedFrames"] = self.clear_screencast(wake_waiters=True)
            return result
        if domain == "Page" and command == "close":
            target_id = self._current_target
            if target_id is None:
                raise RuntimeError("no current tab")
            await self.close_page(target_id)
            return {}

        # Page.navigate, Runtime.evaluate, frame tree, and the other
        # already CDP-shaped sidecar handlers remain direct Juggler calls.
        return await self.call(method, p, session_id=page_session_id)

    async def _execute_cdp_layout_metrics(self, session_id: str | None = None) -> dict[str, Any]:
        """Build the CDP layout-metrics shape from real page measurements.

        Juggler intentionally has no Page.getLayoutMetrics method.  The
        browser still exposes the underlying layout through the page's
        JavaScript environment, so the adapter measures it there instead of
        returning a fake hard-coded viewport or leaking the protocol gap to
        the agent.
        """
        result = await self.call("Runtime.evaluate", {
            "expression": """
                (() => {
                  const root = document.documentElement;
                  const body = document.body;
                  const width = Math.max(
                    window.innerWidth || 0,
                    root?.clientWidth || 0,
                    body?.clientWidth || 0,
                  );
                  const height = Math.max(
                    window.innerHeight || 0,
                    root?.clientHeight || 0,
                    body?.clientHeight || 0,
                  );
                  return {
                    viewportWidth: width,
                    viewportHeight: height,
                    contentWidth: Math.max(
                      root?.scrollWidth || 0,
                      body?.scrollWidth || 0,
                      width,
                    ),
                    contentHeight: Math.max(
                      root?.scrollHeight || 0,
                      body?.scrollHeight || 0,
                      height,
                    ),
                    pageX: window.scrollX || 0,
                    pageY: window.scrollY || 0,
                    deviceScaleFactor: window.devicePixelRatio || 1,
                  };
                })()
            """,
            "returnByValue": True,
        }, session_id=session_id)
        value = (result.get("result") or {}).get("value")
        if not isinstance(value, dict):
            raise RuntimeError(f"could not measure page layout: {result}")
        width = float(value.get("viewportWidth", 0) or 0)
        height = float(value.get("viewportHeight", 0) or 0)
        content_width = float(value.get("contentWidth", width) or width)
        content_height = float(value.get("contentHeight", height) or height)
        page_x = float(value.get("pageX", 0) or 0)
        page_y = float(value.get("pageY", 0) or 0)
        return {
            "contentSize": {"x": 0, "y": 0, "width": content_width, "height": content_height},
            "layoutViewport": {
                "pageX": page_x,
                "pageY": page_y,
                "clientWidth": width,
                "clientHeight": height,
            },
            "visualViewport": {
                "offsetX": 0,
                "offsetY": 0,
                "pageX": page_x,
                "pageY": page_y,
                "clientWidth": width,
                "clientHeight": height,
                "scale": 1,
                "zoom": 1,
            },
        }

    async def _execute_cdp_target(self, command: str, params: dict[str, Any]) -> dict[str, Any]:
        if command == "getTargets":
            infos: list[dict[str, Any]] = []
            for target_id in self._sessions:
                info = dict(self._target_infos.get(target_id, {}))
                info.update({
                    "targetId": target_id,
                    "type": info.get("type", "page"),
                    "url": info.get("url", ""),
                })
                infos.append({
                    **{
                        key: info[key]
                        for key in ("targetId", "type", "browserContextId", "url")
                        if key in info and info[key] is not None
                    },
                    "sessionId": self._sessions[target_id],
                })
            return {"targetInfos": infos}
        if command == "createTarget":
            requested_url = str(params.get("url", "about:blank"))
            page = await self.create_page(
                url="about:blank",
                browser_context_id=params.get("browserContextId"),
            )
            if requested_url != "about:blank":
                # Keep Target.createTarget's URL behavior on the same
                # frame-ready navigation path as the native tab tool.
                from kahin.tools.pilot import navigate as pilot_navigate  # noqa: PLC0415

                raw_navigation = await pilot_navigate(url=requested_url, wait_until="load")
                try:
                    navigation = orjson.loads(raw_navigation)
                except orjson.JSONDecodeError:
                    navigation = {"error": raw_navigation[:1_000]}
                if isinstance(navigation, dict) and navigation.get("error"):
                    raise RuntimeError(f"Target.createTarget navigation failed: {navigation}")
                # A bounded navigation recovery may replace a wedged target
                # while keeping the same browser. Return the live target, not
                # the attach primitive that was closed during recovery.
                page = await self.ensure_page()
            return {"targetId": page["targetId"]}
        if command == "closeTarget":
            target_id = params.get("targetId")
            if not isinstance(target_id, str) or not target_id:
                raise RuntimeError("Target.closeTarget requires targetId")
            await self.close_page(target_id)
            return {}
        if command == "activateTarget":
            target_id = params.get("targetId")
            if not isinstance(target_id, str):
                raise RuntimeError("Target.activateTarget requires targetId")
            await self.switch_page(target_id)
            await self.call("Page.bringToFront")
            return {}
        if command == "attachToTarget":
            target_id = params.get("targetId")
            if not isinstance(target_id, str):
                raise RuntimeError("Target.attachToTarget requires targetId")
            await self.switch_page(target_id)
            return {"sessionId": self._sessions[target_id]}
        if command in {"detachFromTarget", "setAutoAttach"}:
            raise RuntimeError(
                f"Target.{command} is unsupported on Mirage: the Juggler session model "
                "has no Target-domain detach/auto-attach operation; session state is "
                "managed by Browser.attachedToTarget and Browser.detachedFromTarget events"
            )
        if command == "disposeBrowserContext":
            context_id = params.get("browserContextId")
            if not isinstance(context_id, str):
                raise RuntimeError("Target.disposeBrowserContext requires browserContextId")
            return await self.call("Browser.removeBrowserContext", {"browserContextId": context_id})
        return await self.call(f"Target.{command}", params)

    async def _execute_cdp_input(
        self, command: str, params: dict[str, Any], session_id: str | None = None,
    ) -> dict[str, Any]:
        if command == "insertText":
            text = params.get("text", "")
            if not isinstance(text, str):
                raise RuntimeError("Input.insertText text must be a string")
            await self.call("Page.insertText", {"text": text}, session_id=session_id)
            return {}
        if command == "dispatchKeyEvent":
            type_map = {
                "keyDown": "keydown",
                "keyUp": "keyup",
                "rawKeyDown": "rawkeydown",
                "char": "char",
            }
            key_type = type_map.get(params.get("type"))
            if key_type is None:
                raise RuntimeError(f"unknown Input.dispatchKeyEvent type: {params.get('type')}")
            mapped: dict[str, Any] = {
                "type": key_type,
                "key": str(params.get("key", "")),
                "keyCode": int(params.get("windowsVirtualKeyCode", params.get("keyCode", 0)) or 0),
                "location": int(params.get("location", 0) or 0),
                "code": str(params.get("code", "Unidentified")),
                "repeat": bool(params.get("autoRepeat", params.get("repeat", False))),
            }
            if params.get("text") is not None:
                mapped["text"] = params["text"]
            await self.call("Page.dispatchKeyEvent", mapped, session_id=session_id)
            return {}
        if command == "dispatchMouseEvent":
            event_type = params.get("type")
            x = float(params.get("x", 0) or 0)
            y = float(params.get("y", 0) or 0)
            modifiers = int(params.get("modifiers", 0) or 0)
            if event_type == "mouseWheel":
                await self.call("Page.dispatchWheelEvent", {
                    "x": x,
                    "y": y,
                    "deltaX": float(params.get("deltaX", 0) or 0),
                    "deltaY": float(params.get("deltaY", 0) or 0),
                    "deltaZ": 0.0,
                    "modifiers": modifiers,
                }, session_id=session_id)
                return {}
            type_map = {"mousePressed": "mousedown", "mouseReleased": "mouseup", "mouseMoved": "mousemove"}
            juggler_type = type_map.get(event_type)
            if juggler_type is None:
                raise RuntimeError(f"unknown Input.dispatchMouseEvent type: {event_type}")
            button_name = str(params.get("button", "none"))
            button_number = {"left": 0, "middle": 1, "right": 2, "back": 3, "forward": 4, "none": 0}.get(button_name)
            if button_number is None:
                raise RuntimeError(f"unknown mouse button: {button_name}")
            buttons = params.get("buttons")
            if buttons is None:
                buttons = {"left": 1, "right": 2, "middle": 4, "back": 8, "forward": 16}.get(button_name, 0)
                if juggler_type != "mousedown":
                    buttons = 0
            await self.call("Page.dispatchMouseEvent", {
                "type": juggler_type,
                "button": button_number,
                "x": x,
                "y": y,
                "modifiers": modifiers,
                "clickCount": int(params.get("clickCount", 1) or 1),
                "buttons": int(buttons),
            }, session_id=session_id)
            return {}
        return await self.call(f"Input.{command}", params, session_id=session_id)

    async def _execute_cdp_emulation(
        self, command: str, params: dict[str, Any], session_id: str | None = None,
    ) -> dict[str, Any]:
        if command == "setDeviceMetricsOverride":
            width = params.get("width")
            height = params.get("height")
            if (
                isinstance(width, bool)
                or isinstance(height, bool)
                or not isinstance(width, (int, float))
                or not isinstance(height, (int, float))
                or width <= 0
                or height <= 0
            ):
                raise RuntimeError("Emulation.setDeviceMetricsOverride requires width and height")
            if params.get("mobile") is True or params.get("screenOrientation") is not None:
                raise RuntimeError(
                    "Mirage cannot emulate mobile UA/orientation through this CDP adapter; "
                    "use kahin_mirage_set_viewport and kahin_mirage_set_touch explicitly"
                )
            viewport: dict[str, Any] = {
                "viewportSize": {"width": width, "height": height},
            }
            if params.get("deviceScaleFactor") is not None:
                dsf = params["deviceScaleFactor"]
                if isinstance(dsf, bool) or not isinstance(dsf, (int, float)) or dsf <= 0:
                    raise RuntimeError("deviceScaleFactor must be a positive number")
                viewport["deviceScaleFactor"] = params["deviceScaleFactor"]
            context_params: dict[str, Any] = {"viewport": viewport}
            context_id = self.current_browser_context_id()
            if context_id:
                context_params["browserContextId"] = context_id
            await self.call("Browser.setDefaultViewport", context_params)
            return {}
        if command == "setUserAgentOverride":
            user_agent = params.get("userAgent", "")
            if not isinstance(user_agent, str):
                raise RuntimeError("Emulation.setUserAgentOverride userAgent must be a string")
            mapped = {"userAgent": user_agent or None}
            context_id = self.current_browser_context_id()
            if context_id:
                mapped["browserContextId"] = context_id
            res = await self.call("Browser.setUserAgentOverride", mapped)
            sid = session_id or self.current_session_id()
            if user_agent:
                self._user_agent_overrides[context_id or "default"] = user_agent
                if sid:
                    js = f"try {{ Object.defineProperty(Navigator.prototype, 'userAgent', {{ get: () => {json.dumps(user_agent)}, configurable: true }}); }} catch (e) {{}}"
                    try:
                        await self.call("Runtime.evaluate", {"expression": js}, session_id=sid)
                    except Exception:
                        pass
            else:
                self._user_agent_overrides.pop(context_id or "default", None)
                if sid:
                    js = "try { delete Navigator.prototype.userAgent; } catch (e) {}"
                    try:
                        await self.call("Runtime.evaluate", {"expression": js}, session_id=sid)
                    except Exception:
                        pass
            return res
        if command == "setTouchEmulationEnabled":
            enabled = params.get("enabled", False)
            if not isinstance(enabled, bool):
                raise RuntimeError("Emulation.setTouchEmulationEnabled enabled must be a boolean")
            mapped = {"hasTouch": enabled}
            context_id = self.current_browser_context_id()
            if context_id:
                mapped["browserContextId"] = context_id
            return await self.call("Browser.setTouchOverride", mapped)
        if command == "setEmulatedMedia":
            return await self.call(
                "Page.setEmulatedMedia", {"type": params.get("media", "screen")}, session_id=session_id,
            )
        if command == "setLocaleOverride":
            locale = params.get("locale", "")
            if not isinstance(locale, str):
                raise RuntimeError("Emulation.setLocaleOverride locale must be a string")
            mapped = {"locale": locale}
            context_id = self.current_browser_context_id()
            if context_id:
                mapped["browserContextId"] = context_id
            return await self.call("Browser.setLocaleOverride", mapped)
        if command == "setTimezoneOverride":
            timezone = params.get("timezoneId", "")
            if not isinstance(timezone, str):
                raise RuntimeError("Emulation.setTimezoneOverride timezoneId must be a string")
            mapped = {"timezoneId": timezone}
            context_id = self.current_browser_context_id()
            if context_id:
                mapped["browserContextId"] = context_id
            return await self.call("Browser.setTimezoneOverride", mapped)
        if command == "setGeolocationOverride":
            geo = {k: params[k] for k in ("latitude", "longitude", "accuracy") if k in params}
            mapped: dict[str, Any] = {"geolocation": geo or None}
            context_id = self.current_browser_context_id()
            if context_id:
                mapped["browserContextId"] = context_id
            return await self.call("Browser.setGeolocationOverride", mapped)
        return await self.call(f"Emulation.{command}", params, session_id=session_id)

    async def _execute_cdp_network(
        self, command: str, params: dict[str, Any], session_id: str | None = None,
    ) -> dict[str, Any]:
        if command == "setUserAgentOverride":
            return await self._execute_cdp_emulation("setUserAgentOverride", params, session_id=session_id)
        if command == "continueInterceptedRequest":
            request_id = params.get("requestId")
            if not isinstance(request_id, str) or not request_id:
                raise RuntimeError("Network.continueInterceptedRequest requires a non-empty requestId")
            mapped: dict[str, Any] = {"requestId": request_id}
            for key in ("url", "method", "postData"):
                if key in params:
                    if not isinstance(params[key], str):
                        raise RuntimeError(f"Network.continueInterceptedRequest {key} must be a string")
                    mapped[key] = params[key]
            if "headers" in params:
                headers = params["headers"]
                if isinstance(headers, dict):
                    if not all(
                        isinstance(name, str) and isinstance(value, str)
                        for name, value in headers.items()
                    ):
                        raise RuntimeError(
                            "Network.continueInterceptedRequest header names and values must be strings"
                        )
                    mapped["headers"] = [
                        {"name": name, "value": value}
                        for name, value in headers.items()
                    ]
                elif isinstance(headers, list) and all(
                    isinstance(header, dict)
                    and isinstance(header.get("name"), str)
                    and isinstance(header.get("value"), str)
                    for header in headers
                ):
                    mapped["headers"] = headers
                else:
                    raise RuntimeError(
                        "Network.continueInterceptedRequest headers must be a CDP object "
                        "or a list of {name,value} objects"
                    )
            return await self.call("Network.resumeInterceptedRequest", mapped, session_id=session_id)
        if command == "setRequestInterception":
            enabled = params.get("enabled", True)
            if not isinstance(enabled, bool):
                raise RuntimeError("Network.setRequestInterception enabled must be a boolean")
            patterns = params.get("patterns")
            if patterns not in (None, []):
                raise RuntimeError(
                    "Mirage cannot apply CDP Network.setRequestInterception patterns: "
                    "Juggler exposes a page-wide toggle, so patterns are rejected instead of dropped"
                )
            return await self.call(
                "Network.setRequestInterception",
                {"enabled": enabled},
                session_id=session_id,
            )
        if command == "getResponseBody":
            request_id = params.get("requestId")
            if not isinstance(request_id, str) or not request_id:
                raise RuntimeError("Network.getResponseBody requires a non-empty requestId")
            result = await self.get_response_body(request_id, session_id=session_id)
            raw = result.get("base64body") if isinstance(result, dict) else None
            if not isinstance(raw, str):
                raise RuntimeError("Juggler Network.getResponseBody returned no base64body")
            max_chars = ((1024 * 1024 + 2) // 3) * 4
            if len(raw) > max_chars:
                raise RuntimeError("Network.getResponseBody exceeds the 1 MiB response limit")
            try:
                body_bytes = base64.b64decode(raw, validate=True)
            except Exception as exc:  # noqa: BLE001
                raise RuntimeError(f"Juggler returned invalid base64body: {exc}") from exc
            try:
                body = body_bytes.decode("utf-8")
            except UnicodeDecodeError:
                body = raw
                base64_encoded = True
            else:
                base64_encoded = False
            response: dict[str, Any] = {"body": body, "base64Encoded": base64_encoded}
            if isinstance(result, dict) and "evicted" in result:
                response["evicted"] = result["evicted"]
            return response
        if command == "clearBrowserCookies":
            return await self.call("Browser.clearCookies", {})
        if command == "clearBrowserCache":
            return await self.call("Browser.clearCache", {})
        if command == "setCacheDisabled":
            disabled = params.get("cacheDisabled", False)
            if not isinstance(disabled, bool):
                raise RuntimeError("Network.setCacheDisabled cacheDisabled must be a boolean")
            return await self.call(
                "Page.setCacheDisabled", {"cacheDisabled": disabled}, session_id=session_id,
            )
        return await self.call(f"Network.{command}", params, session_id=session_id)

    # --- liveness ---

    async def send_cdp(self, *args: Any, **kwargs: Any) -> dict[str, Any]:
        """Removed in Faz 9 Task 3 — the Juggler wire is call() only."""
        raise RuntimeError(
            "Mirage.send_cdp was removed; use Mirage.call(method, params, session_id)"
        )

    async def health(self) -> dict[str, Any]:
        """Probe both the sidecar and its Camoufox child.

        ``is_alive()`` can only see the sidecar process.  Browser.health is
        answered by the sidecar's process manager and catches the stale-state
        case where Firefox has exited but the Python process has not reaped
        the sidecar yet.
        """
        if not self.is_alive():
            return {
                "alive": False,
                "state": "dead",
                "reason": self._death_reason or "sidecar_not_alive",
                "pid": self._process.pid if self._process is not None else None,
                "returncode": self._process.returncode if self._process is not None else None,
                "stderr_log": str(self._stderr_path) if self._stderr_path is not None else None,
            }
        try:
            result = await self.call("Browser.health")
        except Exception as exc:  # noqa: BLE001
            process_alive = (
                not self._dead
                and self._process is not None
                and self._process.returncode is None
            )
            if process_alive:
                # A health RPC error is not proof that the sidecar or
                # browser died. Keep the transport and process lock owned so
                # a transient busy sidecar cannot create a second browser.
                return {
                    "alive": False,
                    "state": "degraded",
                    "reason": "health_probe_failed",
                    "error": str(exc),
                    "pid": self._process.pid,
                    "returncode": self._process.returncode,
                    "stderr_log": str(self._stderr_path) if self._stderr_path is not None else None,
                }
            self._mark_dead(f"health_error:{type(exc).__name__}")
            return {
                "alive": False,
                "state": "dead",
                "error": str(exc),
                "reason": self._death_reason,
                "pid": self._process.pid if self._process is not None else None,
                "returncode": self._process.returncode if self._process is not None else None,
                "stderr_log": str(self._stderr_path) if self._stderr_path is not None else None,
            }
        if not result.get("alive"):
            self._mark_dead("browser_health_dead")
        return result

    def is_alive(self) -> bool:
        """Process up and the reader healthy (reader EOF marks death)."""
        return (
            not self._dead
            and self._process is not None
            and self._process.returncode is None
        )

    def on_death(self, callback: Callable[[], Any]) -> None:
        self._death_callbacks.append(callback)  # type: ignore[arg-type]

    async def screenshot(self, format: str = "png", full_page: bool = False) -> bytes:
        """Page.captureScreenshot passthrough. The sidecar translates
        full_page into a full-content clip (size measured via evaluate);
        otherwise the real viewport is captured."""
        await self.ensure_page()
        result = await self.call("Page.captureScreenshot", {"format": format, "fullPage": full_page})
        data = result.get("data")
        if not isinstance(data, str) or not data.strip():
            raise RuntimeError(f"captureScreenshot returned no data: {result}")
        return base64.b64decode(data)

    async def stop(self) -> None:
        self._stopping = True
        self._dom_signal.set()
        self._reset_capture_state(wake_waiters=True)
        self._identity_config = None
        self._identity_name = None
        self._proxy_url = None
        self._identity_hash = None
        self._prewarm_info = None
        self._launch_policy = None
        self._started_monotonic = None
        geometry_task, self._geometry_task = self._geometry_task, None
        if geometry_task is not None:
            geometry_task.cancel()
        self._marionette_port = None
        self._passkey_mode = False
        for fut in self._pending.values():
            if not fut.done():
                fut.cancel()
        self._pending.clear()
        proc, self._process = self._process, None
        try:
            if proc is not None:
                if proc.stdin:
                    try:
                        proc.stdin.close()  # stdin EOF -> sidecar stops the browser
                    except Exception:  # noqa: BLE001
                        pass
                wait_task = asyncio.create_task(proc.wait())
                try:
                    await asyncio.wait_for(asyncio.shield(wait_task), timeout=_SIDECAR_SHUTDOWN_TIMEOUT)
                except ProcessLookupError:
                    # The sidecar may already have been reaped by its
                    # reader/death path. Cleanup is idempotent.
                    pass
                except TimeoutError:
                    try:
                        proc.kill()
                    except ProcessLookupError:
                        pass
                    try:
                        await asyncio.wait_for(asyncio.shield(wait_task), timeout=_SIDECAR_KILL_TIMEOUT)
                    except TimeoutError:
                        # A sidecar stuck while its browser is dying must not
                        # hold an MCP shutdown request forever. The kill was
                        # already sent; cancel only the local waiter after the
                        # bounded reap window.
                        wait_task.cancel()
                        try:
                            await wait_task
                        except BaseException:  # noqa: BLE001 - waiter is cancelled
                            pass
                    except ProcessLookupError:
                        pass
                except asyncio.CancelledError:
                    # A cancelled MCP request must still reap the sidecar
                    # before the cancellation escapes; otherwise the next tool
                    # sees a cleared Python state with a live child underneath.
                    try:
                        proc.kill()
                    except ProcessLookupError:
                        pass
                    await asyncio.shield(wait_task)
                    raise
        finally:
            # The reader must keep draining stdout until the sidecar is gone:
            # while it is alive it may still flush a large final response, and
            # a cancelled reader would let the 64 KiB pipe fill and wedge the
            # sidecar mid-shutdown. Cancel it only now.
            reader, self._reader = self._reader, None
            if reader is not None:
                reader.cancel()
                if reader is not asyncio.current_task():
                    try:
                        await asyncio.wait_for(asyncio.shield(reader), timeout=_READER_SHUTDOWN_TIMEOUT)
                    except TimeoutError:
                        # A callback or a broken pipe must not turn browser_stop
                        # into a 30-second MCP stall. The reader is already
                        # cancelled; process teardown is authoritative.
                        reader.cancel()
                    except asyncio.CancelledError:
                        pass
                    except Exception:  # noqa: BLE001 - shutdown must continue
                        logger.debug("Mirage reader failed during shutdown", exc_info=True)
            if self._stderr_file is not None:
                self._stderr_file.close()
                self._stderr_file = None
            self._sessions.clear()
            self._target_infos.clear()
            self._frame_contexts.clear()
            self._current_target = None
            self._remove_profile()

    def _remove_profile(self) -> None:
        profile, self._profile_dir = self._profile_dir, None
        mode, self._state_mode = self._state_mode, None
        recorded, self._kes_profile_dir = self._kes_profile_dir, None
        persistent, self._persistent_profile = self._persistent_profile, False
        # kes is "forget me": delete exactly the directory this launch created,
        # and only when it is provably an ephemeral kes path. agirbas state is
        # never touched (spec §2.1/§2.2).
        if mode == STATE_MODE_KES and recorded is not None and profile == recorded:
            _LIVE_KES_DIRS.discard(str(recorded))
            if _is_kes_owned_path(recorded):
                shutil.rmtree(recorded, ignore_errors=True)
            return
        # Back-compat for the legacy non-persistent path.
        if mode is None and profile is not None and not persistent:
            shutil.rmtree(profile, ignore_errors=True)
